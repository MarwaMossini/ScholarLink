<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/auth.php';
$flash = get_flash();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'apply' && is_logged_in() && is_student()) {
    $scholarshipId = (int)($_POST['scholarship_id'] ?? 0);
    $programId = (int)($_POST['program_id'] ?? 0);
    $check = $pdo->prepare('SELECT id FROM applications WHERE student_user_id=? AND scholarship_id=?');
    $check->execute([$_SESSION['user']['id'], $scholarshipId]);
    if (!$check->fetch()) {
        $pdo->prepare('INSERT INTO applications (student_user_id, scholarship_id, program_id, status) VALUES (?, ?, ?, ?)')->execute([$_SESSION['user']['id'], $scholarshipId, $programId ?: null, 'Pending']);
        set_flash('success', 'Application saved. You can track it from your dashboard.');
    } else {
        set_flash('error', 'You already applied to this scholarship.');
    }
    $queryString = $_SERVER['QUERY_STRING'] ?? '';
    header('Location: ' . url('search.php') . ($queryString ? '?' . $queryString : ''));
    exit;
}

$keyword = trim($_GET['keyword'] ?? '');
$country = trim($_GET['country'] ?? '');
$language = trim($_GET['language'] ?? '');
$degree = trim($_GET['degree_level'] ?? '');
$funding = trim($_GET['funding_type'] ?? '');
$gpa = trim($_GET['gpa'] ?? '');
$english = trim($_GET['english_doc_required'] ?? '');
$exam = trim($_GET['entry_exam_required'] ?? '');

$sql = "SELECT s.*, u.name AS university_name, u.website, p.program_name, p.degree_level AS program_degree,
(SELECT ROUND(AVG(rating),1) FROM reviews WHERE entity_type='scholarship' AND entity_id=s.id) AS avg_rating,
CASE WHEN s.donor_user_id IS NOT NULL THEN (SELECT name FROM users WHERE id=s.donor_user_id) ELSE NULL END AS donor_name
FROM scholarships s
LEFT JOIN universities u ON s.university_id=u.id
LEFT JOIN programs p ON s.program_id=p.id
WHERE 1=1";
$params = [];
if ($keyword !== '') { $sql .= " AND (s.title LIKE ? OR p.program_name LIKE ? OR u.name LIKE ? OR s.description LIKE ? )"; $kw = "%$keyword%"; array_push($params, $kw,$kw,$kw,$kw); }
if ($country !== '') { $sql .= " AND s.country LIKE ?"; $params[] = "%$country%"; }
if ($language !== '') { $sql .= " AND s.language_requirement LIKE ?"; $params[] = "%$language%"; }
if ($degree !== '') { $sql .= " AND s.degree_level LIKE ?"; $params[] = "%$degree%"; }
if ($funding !== '') { $sql .= " AND s.funding_type LIKE ?"; $params[] = "%$funding%"; }
if ($gpa !== '') { $sql .= " AND (s.min_gpa IS NULL OR s.min_gpa <= ?)"; $params[] = $gpa; }
if ($english !== '') { $sql .= " AND s.english_doc_required LIKE ?"; $params[] = "%$english%"; }
if ($exam !== '') { $sql .= " AND s.entry_exam_required LIKE ?"; $params[] = "%$exam%"; }
$sql .= " ORDER BY s.scholarship_percentage DESC, s.deadline ASC";
$stmt = $pdo->prepare($sql); $stmt->execute($params); $rows = $stmt->fetchAll();
include __DIR__ . '/partials/header.php';
?>
<div class="form-card">
    <div class="section-title"><h2>Search scholarships and universities</h2><span class="badge">Type university, program, or language</span></div>
    <?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="get">
        <div class="search-grid">
            <div class="form-group wide"><label>Keyword</label><input type="text" name="keyword" value="<?= e($keyword) ?>" placeholder="Computer Science, Oxford, English..."></div>
            <div class="form-group"><label>Country</label><input type="text" name="country" value="<?= e($country) ?>"></div>
            <div class="form-group"><label>Language</label><input type="text" name="language" value="<?= e($language) ?>"></div>
            <div class="form-group"><label>Degree</label><input type="text" name="degree_level" value="<?= e($degree) ?>"></div>
            <div class="form-group"><label>Funding</label><input type="text" name="funding_type" value="<?= e($funding) ?>"></div>
            <div class="form-group"><label>GPA</label><input type="number" step="0.01" name="gpa" value="<?= e($gpa) ?>"></div>
        </div>
        <div class="search-grid compact">
            <div class="form-group"><label>English Proof</label><input type="text" name="english_doc_required" value="<?= e($english) ?>"></div>
            <div class="form-group"><label>Entry Exam</label><input type="text" name="entry_exam_required" value="<?= e($exam) ?>"></div>
            <div class="actions"><button class="btn" type="submit">Search</button><a class="btn secondary" href="search.php">Reset</a></div>
        </div>
    </form>
</div>
<div class="table-card section-spacer">
    <h3>Results</h3>
    <?php if ($rows): ?><table class="table"><tr><th>Scholarship</th><th>University</th><th>Program</th><th>Requirements</th><th>Details</th><th>Action</th></tr><?php foreach($rows as $row): ?><tr><td><strong><?= e($row['title']) ?></strong><br><span class="muted"><?= e($row['description']) ?></span><br><?php if ($row['donor_name']): ?><span class="badge">Donor: <?= e($row['donor_name']) ?></span><?php endif; ?></td><td><?= e($row['university_name']) ?><br><?php if ($row['website']): ?><a class="muted" target="_blank" href="<?= e($row['website']) ?>"><?= e($row['website']) ?></a><?php else: ?><span class="muted"><?= e($row['country']) ?></span><?php endif; ?></td><td><?= e($row['program_name']) ?><br><span class="muted"><?= e($row['degree_level']) ?></span></td><td>GPA: <?= e($row['min_gpa']) ?><br>English: <?= e($row['english_doc_required']) ?><br>Exam: <?= e($row['entry_exam_required']) ?><br>Language: <?= e($row['language_requirement']) ?></td><td><?= e($row['funding_type']) ?> / <?= e($row['scholarship_percentage']) ?>%<br><span class="muted">Deadline: <?= e($row['deadline']) ?></span><br><span class="muted">Rating: <?= e($row['avg_rating'] ?? '—') ?></span></td><td><?php if (is_logged_in() && is_student()): ?><form method="post"><input type="hidden" name="action" value="apply"><input type="hidden" name="scholarship_id" value="<?= e($row['id']) ?>"><input type="hidden" name="program_id" value="<?= e($row['program_id']) ?>"><button class="btn small-btn">Apply</button></form><?php else: ?><a class="btn secondary small-btn" href="login.php">Login to apply</a><?php endif; ?><div class="section-spacer"></div><?php if (!empty($row['application_link'])): ?><a class="btn ghost small-btn" target="_blank" href="<?= e($row['application_link']) ?>">Open link</a><?php else: ?><span class="muted">No external link added yet.</span><?php endif; ?></td></tr><?php endforeach; ?></table><?php else: ?><div class="empty-state">No results found for your filters.</div><?php endif; ?>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
