<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/auth.php';

$error = '';

function generate_public_id(PDO $pdo, string $role): string {
    $prefixes = ['student' => 'SCL', 'mentor' => 'MTR', 'university' => 'UNI', 'donor' => 'DNR'];
    $prefix = $prefixes[$role] ?? 'SCL';
    $stmt = $pdo->prepare('SELECT COUNT(*) + 100001 FROM users WHERE role = ?');
    $stmt->execute([$role]);
    return $prefix . (int)$stmt->fetchColumn();
}

function strong_password(string $password): bool {
    return (bool)preg_match('/^(?=(?:.*[A-Za-z]){5,})(?=.*\d)(?=.*[^A-Za-z\d]).{7,}$/', $password);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'] ?? 'student';
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (!in_array($role, ['student', 'mentor', 'university', 'donor'], true)) {
        $error = 'Choose a valid account type.';
    } elseif ($name === '' || $email === '' || $password === '' || $confirmPassword === '') {
        $error = 'Please fill all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif ($password !== $confirmPassword) {
        $error = 'Passwords do not match.';
    } elseif (!strong_password($password)) {
        $error = 'Password must include at least 5 letters, 1 number, and 1 symbol.';
    } else {
        $check = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $check->execute([$email]);
        if ($check->fetch()) {
            $error = 'Email already exists.';
        } else {
            $pdo->beginTransaction();
            try {
                $publicId = generate_public_id($pdo, $role);
                $stmt = $pdo->prepare('INSERT INTO users (public_id, name, email, password, role) VALUES (?, ?, ?, ?, ?)');
                $stmt->execute([$publicId, $name, $email, password_hash($password, PASSWORD_DEFAULT), $role]);
                $userId = (int)$pdo->lastInsertId();

                if ($role === 'student') {
                    $pdo->prepare('INSERT INTO student_profiles (user_id, country, academic_level, preferred_language, field_of_interest, preferred_country, target_degree, extracurricular_level) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
                        ->execute([
                            $userId,
                            trim($_POST['country'] ?? ''),
                            trim($_POST['academic_level'] ?? ''),
                            trim($_POST['preferred_language'] ?? ''),
                            trim($_POST['field_of_interest'] ?? ''),
                            trim($_POST['preferred_country'] ?? ''),
                            trim($_POST['target_degree'] ?? ''),
                            trim($_POST['extracurricular_level'] ?? 'Moderate')
                        ]);
                } elseif ($role === 'mentor') {
                    $minFee = (float)($_POST['min_session_fee'] ?? 0);
                    $maxFee = (float)($_POST['max_session_fee'] ?? 0);
                    $defaultMinutes = (int)($_POST['default_session_minutes'] ?? 45);
                    if ($minFee <= 0 || $maxFee < $minFee || $defaultMinutes < 15) {
                        throw new RuntimeException('Invalid mentor fee range or duration.');
                    }
                    $pdo->prepare('INSERT INTO mentor_profiles (user_id, degree_title, country_affiliation, expertise_area, bio, hourly_fee, languages_spoken, years_experience, min_session_fee, max_session_fee, default_session_minutes, meeting_platform) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                        ->execute([
                            $userId,
                            trim($_POST['degree_title'] ?? ''),
                            trim($_POST['country_affiliation'] ?? ''),
                            trim($_POST['expertise_area'] ?? ''),
                            trim($_POST['bio'] ?? ''),
                            $minFee,
                            trim($_POST['languages_spoken'] ?? ''),
                            trim($_POST['years_experience'] ?? '') ?: 0,
                            $minFee,
                            $maxFee,
                            $defaultMinutes,
                            trim($_POST['meeting_platform'] ?? 'Google Meet')
                        ]);
                } elseif ($role === 'university') {
                    $pdo->prepare('INSERT INTO university_accounts (user_id, institution_name, country, city, website, contact_title, description) VALUES (?, ?, ?, ?, ?, ?, ?)')
                        ->execute([$userId, trim($_POST['institution_name'] ?? $name), trim($_POST['country'] ?? ''), trim($_POST['city'] ?? ''), trim($_POST['website'] ?? ''), trim($_POST['contact_title'] ?? ''), trim($_POST['description'] ?? '')]);
                } elseif ($role === 'donor') {
                    $pdo->prepare('INSERT INTO donor_profiles (user_id, organization_name, country, website, focus_area, funding_note, contact_title) VALUES (?, ?, ?, ?, ?, ?, ?)')
                        ->execute([$userId, trim($_POST['organization_name'] ?? $name), trim($_POST['country'] ?? ''), trim($_POST['website'] ?? ''), trim($_POST['focus_area'] ?? ''), trim($_POST['funding_note'] ?? ''), trim($_POST['contact_title'] ?? '')]);
                }

                $pdo->commit();
                $_SESSION['signup_success'] = ['id' => $publicId, 'role' => $role, 'email' => $email];
                redirect('signup_success.php');
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) { $pdo->rollBack(); }
                $error = $e instanceof RuntimeException ? $e->getMessage() : 'Could not create account. Please try again.';
            }
        }
    }
}
include __DIR__ . '/partials/header.php';
$selectedRole = $_POST['role'] ?? 'student';
?>
<div class="auth-wrap form-card">
    <h2>Create your ScholarLink account</h2>
    <p class="muted">Choose the role that fits you. After signup, you will get a ScholarLink ID for login.</p>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="post" id="signupForm">
        <div class="form-row three">
            <div class="form-group">
                <label>Account Type</label>
                <select name="role" id="roleSelect" required>
                    <option value="student" <?= $selectedRole==='student'?'selected':'' ?>>Student</option>
                    <option value="mentor" <?= $selectedRole==='mentor'?'selected':'' ?>>Mentor</option>
                    <option value="university" <?= $selectedRole==='university'?'selected':'' ?>>University</option>
                    <option value="donor" <?= $selectedRole==='donor'?'selected':'' ?>>Scholarship Donor</option>
                </select>
            </div>
            <div class="form-group"><label>Full Name / Main Contact</label><input type="text" name="name" value="<?= e($_POST['name'] ?? '') ?>" required></div>
            <div class="form-group"><label>Email</label><input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required></div>
        </div>
        <div class="form-row three">
            <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
            <div class="form-group"><label>Confirm Password</label><input type="password" name="confirm_password" required></div>
            <div class="form-group"><label>Password Rule</label><div class="inline-note strong-box">At least 5 letters, 1 number, and 1 symbol.</div></div>
        </div>

        <div class="role-block role-student <?= $selectedRole==='student'?'':'hidden' ?>">
            <h3>Student details</h3>
            <div class="form-row three">
                <div class="form-group"><label>Country</label><input name="country" value="<?= e($_POST['country'] ?? '') ?>"></div>
                <div class="form-group"><label>Academic Level</label><input name="academic_level" value="<?= e($_POST['academic_level'] ?? '') ?>" placeholder="Bachelor / Master"></div>
                <div class="form-group"><label>Target Degree</label><input name="target_degree" value="<?= e($_POST['target_degree'] ?? '') ?>"></div>
            </div>
            <div class="form-row three">
                <div class="form-group"><label>Field of Interest</label><input name="field_of_interest" value="<?= e($_POST['field_of_interest'] ?? '') ?>"></div>
                <div class="form-group"><label>Preferred Country</label><input name="preferred_country" value="<?= e($_POST['preferred_country'] ?? '') ?>"></div>
                <div class="form-group"><label>Preferred Language</label><input name="preferred_language" value="<?= e($_POST['preferred_language'] ?? '') ?>"></div>
            </div>
            <div class="form-group"><label>Extracurricular Level</label><select name="extracurricular_level"><option>None yet</option><option selected>Moderate</option><option>Strong</option><option>Excellent</option></select></div>
        </div>

        <div class="role-block role-mentor <?= $selectedRole==='mentor'?'':'hidden' ?>">
            <h3>Mentor details</h3>
            <div class="form-row three">
                <div class="form-group"><label>Highest Degree</label><input name="degree_title" value="<?= e($_POST['degree_title'] ?? '') ?>"></div>
                <div class="form-group"><label>Country Affiliation</label><input name="country_affiliation" value="<?= e($_POST['country_affiliation'] ?? '') ?>"></div>
                <div class="form-group"><label>Years of Experience</label><input type="number" min="0" name="years_experience" value="<?= e($_POST['years_experience'] ?? '') ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Expertise Area</label><input name="expertise_area" value="<?= e($_POST['expertise_area'] ?? '') ?>"></div>
                <div class="form-group"><label>Languages Spoken</label><input name="languages_spoken" value="<?= e($_POST['languages_spoken'] ?? '') ?>"></div>
            </div>
            <div class="form-row three">
                <div class="form-group"><label>Minimum Session Fee (USD)</label><input type="number" min="5" max="100" step="0.01" name="min_session_fee" value="<?= e($_POST['min_session_fee'] ?? '12') ?>"></div>
                <div class="form-group"><label>Maximum Session Fee (USD)</label><input type="number" min="5" max="100" step="0.01" name="max_session_fee" value="<?= e($_POST['max_session_fee'] ?? '24') ?>"></div>
                <div class="form-group"><label>Default Session Duration</label><select name="default_session_minutes"><option value="30">30 minutes</option><option value="45" selected>45 minutes</option><option value="60">60 minutes</option><option value="90">90 minutes</option></select></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Meeting Platform</label><select name="meeting_platform"><option>Google Meet</option><option>Zoom</option><option>Microsoft Teams</option><option>Other</option></select></div>
                <div class="form-group"><label>Short Bio</label><textarea name="bio"><?= e($_POST['bio'] ?? '') ?></textarea></div>
            </div>
        </div>

        <div class="role-block role-university <?= $selectedRole==='university'?'':'hidden' ?>">
            <h3>University account details</h3>
            <div class="form-row three">
                <div class="form-group"><label>Institution Name</label><input name="institution_name" value="<?= e($_POST['institution_name'] ?? '') ?>"></div>
                <div class="form-group"><label>Country</label><input name="country" value="<?= e($_POST['country'] ?? '') ?>"></div>
                <div class="form-group"><label>City</label><input name="city" value="<?= e($_POST['city'] ?? '') ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Website</label><input name="website" value="<?= e($_POST['website'] ?? '') ?>"></div>
                <div class="form-group"><label>Contact Title</label><input name="contact_title" value="<?= e($_POST['contact_title'] ?? '') ?>"></div>
            </div>
            <div class="form-group"><label>Description</label><textarea name="description"><?= e($_POST['description'] ?? '') ?></textarea></div>
        </div>

        <div class="role-block role-donor <?= $selectedRole==='donor'?'':'hidden' ?>">
            <h3>Scholarship donor details</h3>
            <div class="form-row three">
                <div class="form-group"><label>Organization Name</label><input name="organization_name" value="<?= e($_POST['organization_name'] ?? '') ?>"></div>
                <div class="form-group"><label>Country</label><input name="country" value="<?= e($_POST['country'] ?? '') ?>"></div>
                <div class="form-group"><label>Focus Area</label><input name="focus_area" value="<?= e($_POST['focus_area'] ?? '') ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Website</label><input name="website" value="<?= e($_POST['website'] ?? '') ?>"></div>
                <div class="form-group"><label>Contact Title</label><input name="contact_title" value="<?= e($_POST['contact_title'] ?? '') ?>"></div>
            </div>
            <div class="form-group"><label>Funding Note</label><textarea name="funding_note"><?= e($_POST['funding_note'] ?? '') ?></textarea></div>
        </div>
        <button class="btn" type="submit">Create account</button>
    </form>
</div>
<script>
const roleSelect = document.getElementById('roleSelect');
function syncRoleBlocks(){
  document.querySelectorAll('.role-block').forEach(block => block.classList.add('hidden'));
  const active = document.querySelector('.role-' + roleSelect.value);
  if(active){ active.classList.remove('hidden'); }
}
roleSelect.addEventListener('change', syncRoleBlocks);
syncRoleBlocks();
</script>
<?php include __DIR__ . '/partials/footer.php'; ?>
