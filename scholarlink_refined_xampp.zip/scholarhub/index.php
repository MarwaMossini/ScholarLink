<?php include __DIR__ . '/partials/header.php'; ?>
<section class="hero-real hero-photo-layout">
    <div class="hero-copy">
        <span class="lead-tag">Scholarships • universities • mentors • donors</span>
        <h1>Move from dreaming to applying with <span class="text-orange">ScholarLink</span></h1>
        <p>ScholarLink helps students discover universities, compare scholarships, ask questions, request mentors, and follow clear application paths. Universities and scholarship donors can publish opportunities, while mentors guide students with session records stored in one responsive platform.</p>
        <div class="actions">
            <a class="btn" href="<?= e(url('signup.php')) ?>">Create account</a>
            <a class="btn secondary" href="<?= e(url('search.php')) ?>">Search opportunities</a>
        </div>
        <div class="hero-bullets">
            <div class="mini-card"><strong>Type your search</strong><p class="muted">Search by university, program, or language and then narrow by country, GPA, funding, English proof, and entry exam.</p></div>
            <div class="mini-card"><strong>Meet verified mentors</strong><p class="muted">Students can request sessions, mentors can accept or reject, and platform payout records keep the fee split visible.</p></div>
            <div class="mini-card"><strong>Trust the details</strong><p class="muted">University websites, scholarship terms, reviews, and program data stay linked together in the database.</p></div>
            <div class="mini-card"><strong>Ask before you apply</strong><p class="muted">Use the Q&amp;A page for common questions on applications, payments, mentors, and documents.</p></div>
        </div>
    </div>
    <div class="hero-image-card">
        <img src="<?= e(url('assets/images/hero-campus.jpg')) ?>" alt="Students studying in a large university lecture hall">
        <div class="image-caption">Students preparing applications, researching programs, and planning their academic future.</div>
    </div>
</section>
<section class="feature-strip">
    <div class="card"><span class="section-kicker">For students</span><h3>Build your profile once</h3><p class="muted">Save GPA, language proof, target country, intake, extracurricular level, and exams for better matches.</p></div>
    <div class="card"><span class="section-kicker">For universities &amp; donors</span><h3>Publish real opportunities</h3><p class="muted">Add university details, websites, programs, scholarships, and see how many students enrolled or applied.</p></div>
    <div class="card"><span class="section-kicker">For mentors</span><h3>Guide students safely</h3><p class="muted">Set your fee range, duration, meeting method, and keep requests, links, and payout records on-platform.</p></div>
</section>
<section class="section-spacer">
    <div class="banner">
        <span class="section-kicker">Why students use ScholarLink</span>
        <h3>One place to search, ask, review, and apply</h3>
        <p>Instead of jumping across many websites, students can discover opportunities, check entry requirements, read reviews, request mentorship, and track applications from one place.</p>
        <div class="actions"><a class="btn" href="<?= e(url('faq.php')) ?>">Open Q&amp;A</a></div>
    </div>
</section>
<?php include __DIR__ . '/partials/footer.php'; ?>
