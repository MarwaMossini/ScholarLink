</main>
<footer class="footer">
    <div class="container footer-row">
        <div>
            <strong>ScholarLink</strong>
            <p class="muted footer-copy">A bright university, scholarship, mentorship, and donor discovery platform built for ambitious students.</p>
        </div>
        <div class="footer-links">
            <a href="<?= e(url('search.php')) ?>">Search</a>
            <a href="<?= e(url('faq.php')) ?>">Q&amp;A</a>
            <a href="<?= e(url('reviews.php')) ?>">Reviews</a>
            <?php if (!is_logged_in()): ?><a href="<?= e(url('signup.php')) ?>">Create account</a><?php endif; ?>
        </div>
    </div>
</footer>
</body>
</html>
