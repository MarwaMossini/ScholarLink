<?php require_once __DIR__ . '/../config/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ScholarLink</title>
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body>
<header class="topbar">
    <div class="container nav-wrap">
        <a class="brand" href="<?= e(url('index.php')) ?>">
            <span class="brand-mark">S</span>
            <span><span class="brand-serif">Scholar</span><span class="brand-accent">Link</span></span>
        </a>
        <nav>
            <a href="<?= e(url('index.php')) ?>">Home</a>
            <a href="<?= e(url('search.php')) ?>">Search</a>
            <a href="<?= e(url('faq.php')) ?>">Q&amp;A</a>
            <a href="<?= e(url('reviews.php')) ?>">Reviews</a>
            <?php if (is_logged_in()): ?>
                <?php if (is_admin()): ?>
                    <a href="<?= e(url('admin/dashboard.php')) ?>">Admin</a>
                <?php elseif (is_mentor()): ?>
                    <a href="<?= e(url('mentor_dashboard.php')) ?>">Mentor</a>
                <?php elseif (is_university()): ?>
                    <a href="<?= e(url('university_dashboard.php')) ?>">University</a>
                <?php elseif (is_donor()): ?>
                    <a href="<?= e(url('donor_dashboard.php')) ?>">Donor</a>
                <?php else: ?>
                    <a href="<?= e(url('dashboard.php')) ?>">Student</a>
                <?php endif; ?>
                <a href="<?= e(url('logout.php')) ?>">Logout</a>
            <?php else: ?>
                <a href="<?= e(url('login.php')) ?>">Login</a>
                <a href="<?= e(url('signup.php')) ?>" class="btn small-btn">Join</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main class="container main-content">
