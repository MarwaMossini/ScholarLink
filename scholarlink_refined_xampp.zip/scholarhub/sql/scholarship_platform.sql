SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS mentor_payments;
DROP TABLE IF EXISTS mentorship_sessions;
DROP TABLE IF EXISTS applications;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS scholarships;
DROP TABLE IF EXISTS programs;
DROP TABLE IF EXISTS universities;
DROP TABLE IF EXISTS donor_profiles;
DROP TABLE IF EXISTS university_accounts;
DROP TABLE IF EXISTS mentor_profiles;
DROP TABLE IF EXISTS student_profiles;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS=1;


CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  public_id VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','student','mentor','university','donor') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE student_profiles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  country VARCHAR(100) DEFAULT NULL,
  academic_level VARCHAR(100) DEFAULT NULL,
  gpa DECIMAL(3,2) DEFAULT NULL,
  field_of_interest VARCHAR(120) DEFAULT NULL,
  preferred_country VARCHAR(120) DEFAULT NULL,
  preferred_language VARCHAR(120) DEFAULT NULL,
  english_proof_status VARCHAR(120) DEFAULT NULL,
  english_test_other VARCHAR(120) DEFAULT NULL,
  entry_exam_status VARCHAR(120) DEFAULT NULL,
  entry_exam_other VARCHAR(120) DEFAULT NULL,
  extracurriculars TEXT DEFAULT NULL,
  extracurricular_level VARCHAR(80) DEFAULT NULL,
  budget_range VARCHAR(120) DEFAULT NULL,
  target_degree VARCHAR(120) DEFAULT NULL,
  target_intake VARCHAR(120) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_student_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE mentor_profiles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  degree_title VARCHAR(120) DEFAULT NULL,
  country_affiliation VARCHAR(120) DEFAULT NULL,
  expertise_area VARCHAR(160) DEFAULT NULL,
  bio TEXT DEFAULT NULL,
  hourly_fee DECIMAL(10,2) DEFAULT 0,
  languages_spoken VARCHAR(160) DEFAULT NULL,
  years_experience INT DEFAULT 0,
  min_session_fee DECIMAL(10,2) DEFAULT 12.00,
  max_session_fee DECIMAL(10,2) DEFAULT 25.00,
  default_session_minutes INT DEFAULT 45,
  meeting_platform VARCHAR(80) DEFAULT 'Google Meet',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_mentor_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE university_accounts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  institution_name VARCHAR(180) NOT NULL,
  country VARCHAR(120) DEFAULT NULL,
  city VARCHAR(120) DEFAULT NULL,
  website VARCHAR(255) DEFAULT NULL,
  contact_title VARCHAR(120) DEFAULT NULL,
  description TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_university_account_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE donor_profiles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  organization_name VARCHAR(180) NOT NULL,
  country VARCHAR(120) DEFAULT NULL,
  website VARCHAR(255) DEFAULT NULL,
  focus_area VARCHAR(180) DEFAULT NULL,
  funding_note TEXT DEFAULT NULL,
  contact_title VARCHAR(120) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_donor_profile_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE universities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  owner_user_id INT DEFAULT NULL,
  name VARCHAR(180) NOT NULL,
  country VARCHAR(120) NOT NULL,
  city VARCHAR(120) DEFAULT NULL,
  website VARCHAR(255) DEFAULT NULL,
  ranking VARCHAR(60) DEFAULT NULL,
  description TEXT DEFAULT NULL,
  language_of_instruction VARCHAR(120) DEFAULT NULL,
  english_requirement VARCHAR(160) DEFAULT NULL,
  entry_exam_requirement VARCHAR(160) DEFAULT NULL,
  tuition_fee VARCHAR(80) DEFAULT NULL,
  status VARCHAR(30) DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_university_owner FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE programs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  university_id INT NOT NULL,
  program_name VARCHAR(180) NOT NULL,
  degree_level VARCHAR(80) DEFAULT NULL,
  duration VARCHAR(80) DEFAULT NULL,
  tuition_fee VARCHAR(80) DEFAULT NULL,
  language_requirement VARCHAR(120) DEFAULT NULL,
  field_category VARCHAR(120) DEFAULT NULL,
  description TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_program_university FOREIGN KEY (university_id) REFERENCES universities(id) ON DELETE CASCADE
);
CREATE TABLE scholarships (
  id INT AUTO_INCREMENT PRIMARY KEY,
  university_id INT NOT NULL,
  program_id INT DEFAULT NULL,
  donor_user_id INT DEFAULT NULL,
  title VARCHAR(220) NOT NULL,
  country VARCHAR(120) DEFAULT NULL,
  degree_level VARCHAR(80) DEFAULT NULL,
  funding_type VARCHAR(80) DEFAULT NULL,
  scholarship_percentage INT DEFAULT 0,
  min_gpa DECIMAL(3,2) DEFAULT NULL,
  english_doc_required VARCHAR(20) DEFAULT NULL,
  entry_exam_required VARCHAR(20) DEFAULT NULL,
  extracurricular_required VARCHAR(20) DEFAULT NULL,
  language_requirement VARCHAR(120) DEFAULT NULL,
  deadline DATE DEFAULT NULL,
  application_link VARCHAR(255) DEFAULT NULL,
  description TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_scholarship_university FOREIGN KEY (university_id) REFERENCES universities(id) ON DELETE CASCADE,
  CONSTRAINT fk_scholarship_program FOREIGN KEY (program_id) REFERENCES programs(id) ON DELETE SET NULL,
  CONSTRAINT fk_scholarship_donor FOREIGN KEY (donor_user_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reviewer_user_id INT NOT NULL,
  entity_type ENUM('university','program','scholarship','mentor') NOT NULL,
  entity_id INT NOT NULL,
  rating INT NOT NULL,
  comment TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_review_user FOREIGN KEY (reviewer_user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_user_id INT NOT NULL,
  scholarship_id INT NOT NULL,
  program_id INT DEFAULT NULL,
  status VARCHAR(30) DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_application_student FOREIGN KEY (student_user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_application_scholarship FOREIGN KEY (scholarship_id) REFERENCES scholarships(id) ON DELETE CASCADE,
  CONSTRAINT fk_application_program FOREIGN KEY (program_id) REFERENCES programs(id) ON DELETE SET NULL
);
CREATE TABLE mentorship_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_user_id INT NOT NULL,
  mentor_user_id INT NOT NULL,
  topic VARCHAR(220) NOT NULL,
  preferred_session_date DATE DEFAULT NULL,
  session_duration_minutes INT DEFAULT 45,
  session_fee DECIMAL(10,2) DEFAULT 0,
  admin_commission DECIMAL(10,2) DEFAULT 0,
  mentor_earning DECIMAL(10,2) DEFAULT 0,
  payment_method VARCHAR(120) DEFAULT NULL,
  payment_status VARCHAR(40) DEFAULT 'Reserved by platform',
  request_status VARCHAR(30) DEFAULT 'Pending',
  meeting_link VARCHAR(255) DEFAULT NULL,
  meeting_platform VARCHAR(80) DEFAULT 'Google Meet',
  student_note VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_session_student FOREIGN KEY (student_user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_session_mentor FOREIGN KEY (mentor_user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE mentor_payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  session_id INT NOT NULL,
  total_amount DECIMAL(10,2) DEFAULT 0,
  admin_amount DECIMAL(10,2) DEFAULT 0,
  mentor_amount DECIMAL(10,2) DEFAULT 0,
  payment_method VARCHAR(120) DEFAULT NULL,
  payment_status VARCHAR(30) DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_payment_session FOREIGN KEY (session_id) REFERENCES mentorship_sessions(id) ON DELETE CASCADE
);

INSERT INTO users (public_id, name, email, password, role) VALUES
('ADM100001', 'Platform Admin', 'admin@scholarhub.test', '$2y$12$j3Tr8.1NZnd/rfJ/e20N5uWLQb.cAMo6oITMJteBzSWVQqhbJn7xW', 'admin'),
('SCL100001', 'Amina Rahimi', 'student@scholarhub.test', '$2y$12$Uq4sBapQCy3WvWGYxyXQ0OT0MTL6ZFNqyAY9za7t993LJNn/Hnsiq', 'student'),
('MTR100001', 'Dr. Sara Karim', 'mentor@scholarhub.test', '$2y$12$wxM6nWjUXA/VhAylsY1MmuGqAU.vbVhN4kDyclVgzdi8YS1f2D7vy', 'mentor'),
('UNI100001', 'Northbridge Admissions', 'university@scholarhub.test', '$2y$12$mViv09nas9KylsnPjy24Ru36NN7xx7zkFal5YBa6ZPeZhkUiBT9h6', 'university'),
('DNR100001', 'Bright Futures Fund', 'donor@scholarhub.test', '$2y$12$CxNARgl7dBYaVT687AW4deRuwOBpPV4QBpxKg2pjWOzyig7XPmCOC', 'donor'),
('MTR100002', 'Ali Reza Mentor', 'mentor2@scholarhub.test', '$2y$12$wxM6nWjUXA/VhAylsY1MmuGqAU.vbVhN4kDyclVgzdi8YS1f2D7vy', 'mentor');

INSERT INTO student_profiles (user_id, country, academic_level, gpa, field_of_interest, preferred_country, preferred_language, english_proof_status, english_test_other, entry_exam_status, entry_exam_other, extracurriculars, extracurricular_level, budget_range, target_degree, target_intake) VALUES
(2,'Afghanistan','Bachelor',3.45,'Computer Science','Canada','English','IELTS',NULL,'GRE',NULL,'Volunteer teaching and coding club','Strong','Moderate','Master','Fall');

INSERT INTO mentor_profiles (user_id, degree_title, country_affiliation, expertise_area, bio, hourly_fee, languages_spoken, years_experience, min_session_fee, max_session_fee, default_session_minutes, meeting_platform) VALUES
(3,'PhD in Education','Canada','Graduate admissions strategy','Mentor for scholarships, essays, and academic planning.',16.00,'English, Persian',8,16.00,26.00,45,'Google Meet'),
(6,'MBA','United Kingdom','Business school applications','Mentor for interviews, essays, and scholarship planning.',14.00,'English, Urdu',6,14.00,24.00,45,'Zoom');

INSERT INTO university_accounts (user_id, institution_name, country, city, website, contact_title, description) VALUES
(4,'Northbridge University','United Kingdom','London','https://northbridge.example.org','Admissions Officer','Demo university account that can publish programs and scholarships.');

INSERT INTO donor_profiles (user_id, organization_name, country, website, focus_area, funding_note, contact_title) VALUES
(5,'Bright Futures Fund','United States','https://brightfutures.example.org','STEM and women in leadership','Covers tuition support for high-potential applicants.','Program Manager');

INSERT INTO universities (owner_user_id, name, country, city, website, ranking, description, language_of_instruction, english_requirement, entry_exam_requirement, tuition_fee, status) VALUES
('4', 'University of Toronto', 'Canada', 'Toronto', 'https://www.utoronto.ca', 'Top 25', 'Leading public research university.', 'English', 'IELTS/TOEFL usually required', 'No general entry exam', '$28,000', 'Active'),
(NULL, 'University of Melbourne', 'Australia', 'Melbourne', 'https://www.unimelb.edu.au', 'Top 40', 'Research-led university with strong graduate programs.', 'English', 'IELTS/TOEFL required', 'No general entry exam', '$30,000', 'Active'),
(NULL, 'Technical University of Munich', 'Germany', 'Munich', 'https://www.tum.de', 'Top 35', 'Strong engineering and science university.', 'English/German', 'English proof for English-track programs', 'Program-specific', '$4,500', 'Active'),
(NULL, 'National University of Singapore', 'Singapore', 'Singapore', 'https://www.nus.edu.sg', 'Top 15', 'Global university with strong analytics and business.', 'English', 'English proof usually required', 'No general entry exam', '$29,000', 'Active'),
(NULL, 'University of British Columbia', 'Canada', 'Vancouver', 'https://www.ubc.ca', 'Top 40', 'Well-known research university on Canada’s west coast.', 'English', 'IELTS/TOEFL usually required', 'No general entry exam', '$27,500', 'Active'),
(NULL, 'University of Sydney', 'Australia', 'Sydney', 'https://www.sydney.edu.au', 'Top 45', 'Prestigious university with strong graduate employability.', 'English', 'IELTS/TOEFL required', 'Program-specific', '$31,500', 'Active'),
(NULL, 'KU Leuven', 'Belgium', 'Leuven', 'https://www.kuleuven.be', 'Top 70', 'Strong academic offering with international scholarships.', 'English', 'English proof usually required', 'No general entry exam', '$6,000', 'Active'),
(NULL, 'Lund University', 'Sweden', 'Lund', 'https://www.lunduniversity.lu.se', 'Top 90', 'International university known for sustainability and research.', 'English', 'English proof required', 'No general entry exam', '$13,000', 'Active'),
(NULL, 'University of Amsterdam', 'Netherlands', 'Amsterdam', 'https://www.uva.nl', 'Top 60', 'Modern European university with diverse programs.', 'English', 'English proof required', 'Program-specific', '$12,500', 'Active'),
(NULL, 'University of Tokyo', 'Japan', 'Tokyo', 'https://www.u-tokyo.ac.jp', 'Top 25', 'Highly ranked university in Asia with research excellence.', 'English/Japanese', 'Depends on program', 'No general entry exam', '$5,200', 'Active'),
(NULL, 'Seoul National University', 'South Korea', 'Seoul', 'https://en.snu.ac.kr', 'Top 35', 'Flagship public university in South Korea.', 'English/Korean', 'Program-specific', 'Some graduate exams', '$7,300', 'Active'),
(NULL, 'ETH Zurich', 'Switzerland', 'Zurich', 'https://ethz.ch', 'Top 10', 'Elite science and engineering university.', 'English', 'English proof required', 'Program-specific', '$2,200', 'Active'),
(NULL, 'University of Auckland', 'New Zealand', 'Auckland', 'https://www.auckland.ac.nz', 'Top 90', 'Largest university in New Zealand.', 'English', 'IELTS/TOEFL usually required', 'No general entry exam', '$25,000', 'Active'),
(NULL, 'University of Warwick', 'United Kingdom', 'Coventry', 'https://warwick.ac.uk', 'Top 70', 'Strong business and STEM reputation.', 'English', 'IELTS/TOEFL required', 'Program-specific', '$32,000', 'Active'),
(NULL, 'University of Birmingham', 'United Kingdom', 'Birmingham', 'https://www.birmingham.ac.uk', 'Top 100', 'Major UK research university with wide scholarship options.', 'English', 'IELTS/TOEFL required', 'Program-specific', '$29,000', 'Active'),
(NULL, 'Arizona State University', 'United States', 'Tempe', 'https://www.asu.edu', 'Top 200', 'Large U.S. university with practical career-aligned programs.', 'English', 'English proof required', 'Tests often optional', '$32,000', 'Active'),
(NULL, 'University of Padua', 'Italy', 'Padua', 'https://www.unipd.it', 'Top 250', 'One of the oldest European universities.', 'English/Italian', 'English proof for English programs', 'No general entry exam', '$3,500', 'Active'),
(NULL, 'University of Science and Technology of China', 'China', 'Hefei', 'https://en.ustc.edu.cn', 'Top 100', 'Strong science and engineering research university.', 'English/Chinese', 'Depends on program', 'Program-specific', '$6,500', 'Active'),
(NULL, 'Sabanci University', 'Turkey', 'Istanbul', 'https://www.sabanciuniv.edu', 'Top 500', 'Private research university in Turkey.', 'English', 'English proof usually required', 'No general entry exam', '$22,000', 'Active'),
(NULL, 'University of Malaya', 'Malaysia', 'Kuala Lumpur', 'https://um.edu.my', 'Top 100', 'Leading public university in Malaysia.', 'English/Malay', 'Depends on program', 'Program-specific', '$7,500', 'Active'),
(NULL, 'King Abdulaziz University', 'Saudi Arabia', 'Jeddah', 'https://www.kau.edu.sa', 'Top 150', 'Large public university with international scholarships.', 'English/Arabic', 'Depends on program', 'No general entry exam', '$0', 'Active'),
(NULL, 'University of Glasgow', 'United Kingdom', 'Glasgow', 'https://www.gla.ac.uk', 'Top 100', 'Historic UK university with strong research culture.', 'English', 'IELTS/TOEFL required', 'Program-specific', '$30,000', 'Active'),
(NULL, 'Politecnico di Milano', 'Italy', 'Milan', 'https://www.polimi.it', 'Top 150', 'Engineering, design, and architecture institution.', 'English/Italian', 'English proof for English tracks', 'Program-specific', '$4,200', 'Active'),
(NULL, 'University of Hong Kong', 'Hong Kong', 'Hong Kong', 'https://www.hku.hk', 'Top 30', 'International university with strong Asia-focused programs.', 'English', 'English proof usually required', 'No general entry exam', '$23,000', 'Active'),
(NULL, 'McGill University', 'Canada', 'Montreal', 'https://www.mcgill.ca', 'Top 35', 'Canadian university with global reputation.', 'English', 'IELTS/TOEFL required', 'No general entry exam', '$29,500', 'Active');

INSERT INTO programs (university_id, program_name, degree_level, duration, tuition_fee, language_requirement, field_category, description) VALUES
('1', 'Computer Science', 'Master', '2 years', '$28,000', 'English', 'STEM', 'Graduate CS program with AI and systems electives.'),
('2', 'Data Science', 'Master', '2 years', '$30,000', 'English', 'STEM', 'Data science with analytics and machine learning focus.'),
('3', 'Mechanical Engineering', 'Master', '2 years', '$4,500', 'English', 'Engineering', 'Advanced mechanical systems and design.'),
('4', 'Business Analytics', 'Master', '1 year', '$29,000', 'English', 'Business', 'Analytics-driven business curriculum.'),
('5', 'Public Health', 'Master', '2 years', '$27,000', 'English', 'Health', 'Public health and policy studies.'),
('6', 'Civil Engineering', 'Bachelor', '4 years', '$31,000', 'English', 'Engineering', 'Undergraduate civil engineering program.'),
('7', 'International Business Economics', 'Master', '1 year', '$6,000', 'English', 'Business', 'Economics and business in global settings.'),
('8', 'Environmental Studies', 'Master', '2 years', '$13,000', 'English', 'Science', 'Sustainability and environment focused.'),
('9', 'Media Studies', 'Bachelor', '3 years', '$12,000', 'English', 'Arts', 'Media, communication, and culture.'),
('10', 'Global Studies', 'Master', '2 years', '$5,000', 'English', 'Social Science', 'International and policy studies.'),
('11', 'Electrical Engineering', 'Master', '2 years', '$7,000', 'English', 'Engineering', 'Power systems and electronics.'),
('12', 'Robotics', 'Master', '2 years', '$2,500', 'English', 'Engineering', 'Robotics and intelligent systems.'),
('13', 'Education', 'Bachelor', '4 years', '$25,000', 'English', 'Education', 'Teacher preparation and education policy.'),
('14', 'Cyber Security', 'Master', '1 year', '$32,000', 'English', 'STEM', 'Security, networks, and digital defense.'),
('15', 'Artificial Intelligence', 'Master', '1 year', '$29,000', 'English', 'STEM', 'Machine learning and AI applications.'),
('16', 'Information Technology', 'Bachelor', '4 years', '$26,000', 'English', 'STEM', 'General IT and software systems.'),
('17', 'Agricultural Science', 'Master', '2 years', '$3,000', 'English', 'Science', 'Agricultural research and innovation.'),
('18', 'Physics', 'PhD', '4 years', '$0', 'English', 'Science', 'Doctoral physics program.'),
('19', 'Economics', 'Bachelor', '4 years', '$18,000', 'English', 'Business', 'Economics for global markets.'),
('20', 'Biomedical Science', 'Master', '2 years', '$6,500', 'English', 'Health', 'Research-oriented biomedical training.'),
('21', 'Software Engineering', 'Bachelor', '4 years', '$24,000', 'English', 'STEM', 'Software development and engineering practice.'),
('22', 'Architecture', 'Master', '2 years', '$11,000', 'English', 'Design', 'Architecture and built environment.'),
('23', 'Renewable Energy Engineering', 'Master', '2 years', '$9,000', 'English', 'Engineering', 'Energy systems and sustainability.'),
('24', 'International Relations', 'Master', '2 years', '$14,000', 'English', 'Social Science', 'Policy, diplomacy, and international systems.'),
('25', 'Finance', 'Master', '1 year', '$27,000', 'English', 'Business', 'Corporate finance and investment analysis.'),
('1', 'Biotechnology', 'Master', '2 years', '$10,500', 'English', 'Science', 'Biotech research and commercialization.'),
('2', 'Nursing', 'Bachelor', '4 years', '$17,000', 'English', 'Health', 'Clinical nursing and healthcare practice.'),
('3', 'Law', 'Master', '1 year', '$20,000', 'English', 'Law', 'International law and legal research.'),
('4', 'Marketing', 'Master', '1 year', '$18,000', 'English', 'Business', 'Modern marketing and consumer strategy.'),
('5', 'Supply Chain Management', 'Master', '1 year', '$19,000', 'English', 'Business', 'Operations, logistics, and analytics.'),
('6', 'Development Studies', 'Master', '2 years', '$8,500', 'English', 'Social Science', 'Development policy and global inequality.'),
('7', 'Psychology', 'Bachelor', '4 years', '$16,000', 'English', 'Social Science', 'Behavior, cognition, and research methods.'),
('8', 'Digital Design', 'Bachelor', '3 years', '$15,000', 'English', 'Design', 'Interface, graphic, and digital media design.'),
('9', 'Chemical Engineering', 'Master', '2 years', '$12,500', 'English', 'Engineering', 'Process, reaction, and plant engineering.'),
('10', 'Mathematics', 'PhD', '4 years', '$0', 'English', 'Science', 'Advanced mathematics and theoretical research.');

INSERT INTO scholarships (university_id, program_id, donor_user_id, title, country, degree_level, funding_type, scholarship_percentage, min_gpa, english_doc_required, entry_exam_required, extracurricular_required, language_requirement, deadline, application_link, description) VALUES
('1', '1', NULL, 'University of Toronto Computer Science Scholarship 1', 'Canada', 'Master', 'Partial', '60', '2.85', 'No', 'Yes', 'No', 'English', '2026-05-10', 'https://example.org/apply/1', 'Scholarship for Computer Science applicants with strong potential.'),
('2', '2', NULL, 'University of Melbourne Data Science Scholarship 2', 'Australia', 'Master', 'Merit-based', '70', '3.0', 'Yes', 'No', 'Yes', 'English', '2026-05-19', 'https://example.org/apply/2', 'Scholarship for Data Science applicants with strong potential.'),
('3', '3', NULL, 'Technical University of Munich Mechanical Engineering Scholarship 3', 'Germany', 'Master', 'Fully Funded', '75', '3.15', 'No', 'Yes', 'No', 'English', '2026-05-28', 'https://example.org/apply/3', 'Scholarship for Mechanical Engineering applicants with strong potential.'),
('4', '4', '5', 'National University of Singapore Business Analytics Scholarship 4', 'Singapore', 'Master', 'Partial', '80', '3.3', 'Yes', 'No', 'Yes', 'English', '2026-06-06', 'https://example.org/apply/4', 'Scholarship for Business Analytics applicants with strong potential.'),
('5', '5', NULL, 'University of British Columbia Public Health Scholarship 5', 'Canada', 'Master', 'Merit-based', '100', '3.45', 'No', 'Yes', 'No', 'English/French', '2026-06-15', 'https://example.org/apply/5', 'Scholarship for Public Health applicants with strong potential.'),
('6', '6', NULL, 'University of Sydney Civil Engineering Scholarship 6', 'Australia', 'Bachelor', 'Fully Funded', '50', '2.7', 'Yes', 'No', 'Yes', 'English', '2026-06-24', 'https://example.org/apply/6', 'Scholarship for Civil Engineering applicants with strong potential.'),
('7', '7', NULL, 'KU Leuven International Business Economics Scholarship 7', 'Belgium', 'Master', 'Partial', '60', '2.85', 'No', 'Yes', 'No', 'English', '2026-07-03', 'https://example.org/apply/7', 'Scholarship for International Business Economics applicants with strong potential.'),
('8', '8', '5', 'Lund University Environmental Studies Scholarship 8', 'Sweden', 'Master', 'Merit-based', '70', '3.0', 'Yes', 'No', 'Yes', 'English', '2026-07-12', 'https://example.org/apply/8', 'Scholarship for Environmental Studies applicants with strong potential.'),
('9', '9', NULL, 'University of Amsterdam Media Studies Scholarship 9', 'Netherlands', 'Bachelor', 'Fully Funded', '75', '3.15', 'No', 'Yes', 'No', 'English', '2026-07-21', 'https://example.org/apply/9', 'Scholarship for Media Studies applicants with strong potential.'),
('10', '10', NULL, 'University of Tokyo Global Studies Scholarship 10', 'Japan', 'Master', 'Partial', '80', '3.3', 'Yes', 'No', 'Yes', 'English/French', '2026-07-30', 'https://example.org/apply/10', 'Scholarship for Global Studies applicants with strong potential.'),
('11', '11', NULL, 'Seoul National University Electrical Engineering Scholarship 11', 'South Korea', 'Master', 'Merit-based', '100', '3.45', 'No', 'Yes', 'No', 'English', '2026-08-08', 'https://example.org/apply/11', 'Scholarship for Electrical Engineering applicants with strong potential.'),
('12', '12', '5', 'ETH Zurich Robotics Scholarship 12', 'Switzerland', 'Master', 'Fully Funded', '50', '2.7', 'Yes', 'No', 'Yes', 'English', '2026-08-17', 'https://example.org/apply/12', 'Scholarship for Robotics applicants with strong potential.'),
('13', '13', NULL, 'University of Auckland Education Scholarship 13', 'New Zealand', 'Bachelor', 'Partial', '60', '2.85', 'No', 'Yes', 'No', 'English', '2026-08-26', 'https://example.org/apply/13', 'Scholarship for Education applicants with strong potential.'),
('14', '14', NULL, 'University of Warwick Cyber Security Scholarship 14', 'United Kingdom', 'Master', 'Merit-based', '70', '3.0', 'Yes', 'No', 'Yes', 'English', '2026-09-04', 'https://example.org/apply/14', 'Scholarship for Cyber Security applicants with strong potential.'),
('15', '15', NULL, 'University of Birmingham Artificial Intelligence Scholarship 15', 'United Kingdom', 'Master', 'Fully Funded', '75', '3.15', 'No', 'Yes', 'No', 'English/French', '2026-09-13', 'https://example.org/apply/15', 'Scholarship for Artificial Intelligence applicants with strong potential.'),
('16', '16', '5', 'Arizona State University Information Technology Scholarship 16', 'United States', 'Bachelor', 'Partial', '80', '3.3', 'Yes', 'No', 'Yes', 'English', '2026-09-22', 'https://example.org/apply/16', 'Scholarship for Information Technology applicants with strong potential.'),
('17', '17', NULL, 'University of Padua Agricultural Science Scholarship 17', 'Italy', 'Master', 'Merit-based', '100', '3.45', 'No', 'Yes', 'No', 'English', '2026-10-01', 'https://example.org/apply/17', 'Scholarship for Agricultural Science applicants with strong potential.'),
('18', '18', NULL, 'University of Science and Technology of China Physics Scholarship 18', 'China', 'PhD', 'Fully Funded', '50', '2.7', 'Yes', 'No', 'Yes', 'English', '2026-10-10', 'https://example.org/apply/18', 'Scholarship for Physics applicants with strong potential.'),
('19', '19', NULL, 'Sabanci University Economics Scholarship 19', 'Turkey', 'Bachelor', 'Partial', '60', '2.85', 'No', 'Yes', 'No', 'English', '2026-10-19', 'https://example.org/apply/19', 'Scholarship for Economics applicants with strong potential.'),
('20', '20', '5', 'University of Malaya Biomedical Science Scholarship 20', 'Malaysia', 'Master', 'Merit-based', '70', '3.0', 'Yes', 'No', 'Yes', 'English/French', '2026-10-28', 'https://example.org/apply/20', 'Scholarship for Biomedical Science applicants with strong potential.'),
('21', '21', NULL, 'King Abdulaziz University Software Engineering Scholarship 21', 'Saudi Arabia', 'Bachelor', 'Fully Funded', '75', '3.15', 'No', 'Yes', 'No', 'English', '2026-11-06', 'https://example.org/apply/21', 'Scholarship for Software Engineering applicants with strong potential.'),
('22', '22', NULL, 'University of Glasgow Architecture Scholarship 22', 'United Kingdom', 'Master', 'Partial', '80', '3.3', 'Yes', 'No', 'Yes', 'English', '2026-11-15', 'https://example.org/apply/22', 'Scholarship for Architecture applicants with strong potential.'),
('23', '23', NULL, 'Politecnico di Milano Renewable Energy Engineering Scholarship 23', 'Italy', 'Master', 'Merit-based', '100', '3.45', 'No', 'Yes', 'No', 'English', '2026-11-24', 'https://example.org/apply/23', 'Scholarship for Renewable Energy Engineering applicants with strong potential.'),
('24', '24', '5', 'University of Hong Kong International Relations Scholarship 24', 'Hong Kong', 'Master', 'Fully Funded', '50', '2.7', 'Yes', 'No', 'Yes', 'English', '2026-12-03', 'https://example.org/apply/24', 'Scholarship for International Relations applicants with strong potential.'),
('25', '25', NULL, 'McGill University Finance Scholarship 25', 'Canada', 'Master', 'Partial', '60', '2.85', 'No', 'Yes', 'No', 'English/French', '2026-12-12', 'https://example.org/apply/25', 'Scholarship for Finance applicants with strong potential.'),
('1', '26', NULL, 'University of Toronto Biotechnology Scholarship 26', 'Canada', 'Master', 'Merit-based', '70', '3.0', 'Yes', 'No', 'Yes', 'English', '2026-12-21', 'https://example.org/apply/26', 'Scholarship for Biotechnology applicants with strong potential.'),
('2', '27', NULL, 'University of Melbourne Nursing Scholarship 27', 'Australia', 'Bachelor', 'Fully Funded', '75', '3.15', 'No', 'Yes', 'No', 'English', '2026-12-30', 'https://example.org/apply/27', 'Scholarship for Nursing applicants with strong potential.'),
('3', '28', '5', 'Technical University of Munich Law Scholarship 28', 'Germany', 'Master', 'Partial', '80', '3.3', 'Yes', 'No', 'Yes', 'English', '2027-01-08', 'https://example.org/apply/28', 'Scholarship for Law applicants with strong potential.'),
('4', '29', NULL, 'National University of Singapore Marketing Scholarship 29', 'Singapore', 'Master', 'Merit-based', '100', '3.45', 'No', 'Yes', 'No', 'English', '2027-01-17', 'https://example.org/apply/29', 'Scholarship for Marketing applicants with strong potential.'),
('5', '30', NULL, 'University of British Columbia Supply Chain Management Scholarship 30', 'Canada', 'Master', 'Fully Funded', '50', '2.7', 'Yes', 'No', 'Yes', 'English/French', '2027-01-26', 'https://example.org/apply/30', 'Scholarship for Supply Chain Management applicants with strong potential.'),
('6', '31', NULL, 'University of Sydney Development Studies Scholarship 31', 'Australia', 'Master', 'Partial', '60', '2.85', 'No', 'Yes', 'No', 'English', '2027-02-04', 'https://example.org/apply/31', 'Scholarship for Development Studies applicants with strong potential.'),
('7', '32', '5', 'KU Leuven Psychology Scholarship 32', 'Belgium', 'Bachelor', 'Merit-based', '70', '3.0', 'Yes', 'No', 'Yes', 'English', '2027-02-13', 'https://example.org/apply/32', 'Scholarship for Psychology applicants with strong potential.'),
('8', '33', NULL, 'Lund University Digital Design Scholarship 33', 'Sweden', 'Bachelor', 'Fully Funded', '75', '3.15', 'No', 'Yes', 'No', 'English', '2027-02-22', 'https://example.org/apply/33', 'Scholarship for Digital Design applicants with strong potential.'),
('9', '34', NULL, 'University of Amsterdam Chemical Engineering Scholarship 34', 'Netherlands', 'Master', 'Partial', '80', '3.3', 'Yes', 'No', 'Yes', 'English', '2027-03-03', 'https://example.org/apply/34', 'Scholarship for Chemical Engineering applicants with strong potential.'),
('10', '35', NULL, 'University of Tokyo Mathematics Scholarship 35', 'Japan', 'PhD', 'Merit-based', '100', '3.45', 'No', 'Yes', 'No', 'English/French', '2027-03-12', 'https://example.org/apply/35', 'Scholarship for Mathematics applicants with strong potential.'),
('1', '1', '5', 'University of Toronto Computer Science Scholarship 36', 'Canada', 'Master', 'Fully Funded', '50', '2.7', 'Yes', 'No', 'Yes', 'English', '2027-03-21', 'https://example.org/apply/36', 'Scholarship for Computer Science applicants with strong potential.'),
('2', '2', NULL, 'University of Melbourne Data Science Scholarship 37', 'Australia', 'Master', 'Partial', '60', '2.85', 'No', 'Yes', 'No', 'English', '2027-03-30', 'https://example.org/apply/37', 'Scholarship for Data Science applicants with strong potential.'),
('3', '3', NULL, 'Technical University of Munich Mechanical Engineering Scholarship 38', 'Germany', 'Master', 'Merit-based', '70', '3.0', 'Yes', 'No', 'Yes', 'English', '2027-04-08', 'https://example.org/apply/38', 'Scholarship for Mechanical Engineering applicants with strong potential.'),
('4', '4', NULL, 'National University of Singapore Business Analytics Scholarship 39', 'Singapore', 'Master', 'Fully Funded', '75', '3.15', 'No', 'Yes', 'No', 'English', '2027-04-17', 'https://example.org/apply/39', 'Scholarship for Business Analytics applicants with strong potential.'),
('5', '5', '5', 'University of British Columbia Public Health Scholarship 40', 'Canada', 'Master', 'Partial', '80', '3.3', 'Yes', 'No', 'Yes', 'English/French', '2027-04-26', 'https://example.org/apply/40', 'Scholarship for Public Health applicants with strong potential.');

INSERT INTO reviews (reviewer_user_id, entity_type, entity_id, rating, comment) VALUES
('2', 'university', '1', '5', 'Very clear admission information and a strong global reputation.'),
('2', 'scholarship', '1', '4', 'Good funding support and easy-to-understand requirements.'),
('2', 'mentor', '3', '5', 'Helpful mentor with practical application advice.'),
('2', 'program', '1', '4', 'Program structure looks strong for research-focused students.');

INSERT INTO applications (student_user_id, scholarship_id, program_id, status) VALUES
(2,1,1,'Pending'),
(2,4,4,'Shortlisted'),
(2,8,8,'Pending'),
(2,12,12,'Approved');

INSERT INTO mentorship_sessions (student_user_id, mentor_user_id, topic, preferred_session_date, session_duration_minutes, session_fee, admin_commission, mentor_earning, payment_method, payment_status, request_status, meeting_link, meeting_platform, student_note) VALUES
(2,3,'Improve graduate admission profile','2026-04-20',45,18.00,1.80,16.20,'Card via platform','Held by platform','Scheduled','https://meet.google.com/demo-scholarlink','Google Meet','Need help with shortlisting and essays'),
(2,6,'Business school interview preparation','2026-04-25',45,16.00,1.60,14.40,'Bank transfer via platform','Reserved by platform','Pending',NULL,'Zoom','Need mock interview support');

INSERT INTO mentor_payments (session_id, total_amount, admin_amount, mentor_amount, payment_method, payment_status) VALUES
(1,18.00,1.80,16.20,'Card via platform','Held'),
(2,16.00,1.60,14.40,'Bank transfer via platform','Reserved');
