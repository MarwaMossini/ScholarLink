<?php include __DIR__ . '/partials/header.php'; ?>
<div class="form-card">
    <span class="section-kicker">Q&amp;A</span>
    <h2>Common questions students ask before applying</h2>
    <p class="muted section-intro">This page answers the most common questions about applications, mentors, payments, reviews, and recommendations.</p>
    <div class="faq-list">
        <details class="faq-item" open><summary>How do mentor sessions work after a mentor accepts?</summary><p>Once accepted, the mentor adds the meeting link and the session becomes scheduled. The student can then see the link and session status from the dashboard.</p></details>
        <details class="faq-item"><summary>How does ScholarLink stop mentors from bypassing the website?</summary><p>The platform stores the payment record first. Payout stays on hold until the session is completed, which makes the platform commission and mentor share visible in admin reports.</p></details>
        <details class="faq-item"><summary>Can I search by language without using a dropdown?</summary><p>Yes. Program, university, and language search boxes are typed inputs so students can enter any language or mixed requirement they want.</p></details>
        <details class="faq-item"><summary>What if I do not have IELTS or TOEFL?</summary><p>Use the English test dropdown and choose <strong>Other</strong> if your proof is different, such as B1 German or another language certificate.</p></details>
        <details class="faq-item"><summary>Why do some scholarships not show as recommendations?</summary><p>Recommendations use your GPA, target degree, preferred country, language, and field. If none match at the moment, the system tells you that there are no recommendations right now.</p></details>
        <details class="faq-item"><summary>Can universities and donors track interest?</summary><p>Yes. University and donor dashboards can see how many students applied or enrolled in their listed programs and scholarships.</p></details>
    </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
