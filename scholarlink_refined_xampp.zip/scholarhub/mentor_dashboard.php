<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/auth.php';
require_login();
require_role('mentor');

$userId = (int)$_SESSION['user']['id'];
$flash = get_flash();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_profile') {
    $minFee = (float)($_POST['min_session_fee'] ?? 0);
    $maxFee = (float)($_POST['max_session_fee'] ?? 0);
    $defaultMinutes = (int)($_POST['default_session_minutes'] ?? 45);
    if ($minFee <= 0 || $maxFee < $minFee) {
        $error = 'Fee range is invalid.';
    } else {
        $pdo->prepare('UPDATE mentor_profiles SET degree_title=?, country_affiliation=?, expertise_area=?, bio=?, hourly_fee=?, languages_spoken=?, years_experience=?, min_session_fee=?, max_session_fee=?, default_session_minutes=?, meeting_platform=? WHERE user_id=?')
            ->execute([
                trim($_POST['degree_title'] ?? ''),
                trim($_POST['country_affiliation'] ?? ''),
                trim($_POST['expertise_area'] ?? ''),
                trim($_POST['bio'] ?? ''),
                $minFee,
                trim($_POST['languages_spoken'] ?? ''),
                trim($_POST['years_experience'] ?? '') ?: 0,
                $minFee,
                $maxFee,
                $defaultMinutes,
                trim($_POST['meeting_platform'] ?? 'Google Meet'),
                $userId
            ]);
        set_flash('success', 'Mentor profile updated.');
        redirect('mentor_dashboard.php');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_request') {
    $sessionId = (int)($_POST['session_id'] ?? 0);
    $newStatus = $_POST['new_status'] ?? 'Pending';
    if (in_array($newStatus, ['Accepted', 'Rejected', 'Completed'], true)) {
        if ($newStatus === 'Accepted') {
            $pdo->prepare('UPDATE mentorship_sessions SET request_status=?, payment_status=? WHERE id=? AND mentor_user_id=?')->execute(['Accepted', 'Held by platform', $sessionId, $userId]);
            $pdo->prepare('UPDATE mentor_payments SET payment_status=? WHERE session_id=?')->execute(['Held', $sessionId]);
        } elseif ($newStatus === 'Rejected') {
            $pdo->prepare('UPDATE mentorship_sessions SET request_status=?, payment_status=? WHERE id=? AND mentor_user_id=?')->execute(['Rejected', 'Refunded', $sessionId, $userId]);
            $pdo->prepare('UPDATE mentor_payments SET payment_status=? WHERE session_id=?')->execute(['Refunded', $sessionId]);
        } elseif ($newStatus === 'Completed') {
            $pdo->prepare('UPDATE mentorship_sessions SET request_status=? WHERE id=? AND mentor_user_id=?')->execute(['Completed', $sessionId, $userId]);
        }
        set_flash('success', 'Request updated.');
        redirect('mentor_dashboard.php');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'set_meeting') {
    $sessionId = (int)($_POST['session_id'] ?? 0);
    $meetingLink = trim($_POST['meeting_link'] ?? '');
    $meetingPlatform = trim($_POST['meeting_platform'] ?? 'Google Meet');
    if ($meetingLink === '') {
        $error = 'Please add a meeting link.';
    } else {
        $pdo->prepare('UPDATE mentorship_sessions SET meeting_link=?, meeting_platform=?, request_status=? WHERE id=? AND mentor_user_id=? AND request_status IN ("Accepted","Scheduled")')
            ->execute([$meetingLink, $meetingPlatform, 'Scheduled', $sessionId, $userId]);
        set_flash('success', 'Meeting link saved. The student can now join from the dashboard.');
        redirect('mentor_dashboard.php');
    }
}

$profile = $pdo->prepare('SELECT * FROM mentor_profiles WHERE user_id=?'); $profile->execute([$userId]); $profile = $profile->fetch();
$requests = $pdo->prepare("SELECT ms.*, u.name AS student_name, u.public_id AS student_public_id FROM mentorship_sessions ms JOIN users u ON u.id=ms.student_user_id WHERE ms.mentor_user_id=? ORDER BY ms.created_at DESC");
$requests->execute([$userId]); $requests = $requests->fetchAll();
$stats = ['pending'=>0,'accepted'=>0,'earnings'=>0.0,'commission'=>0.0];
foreach ($requests as $r) {
    if ($r['request_status']==='Pending') $stats['pending']++;
    if (in_array($r['request_status'], ['Accepted','Scheduled','Completed'], true)) $stats['accepted']++;
    if (($r['payment_status'] ?? '') === 'Released to mentor') {$stats['earnings'] += (float)$r['mentor_earning']; $stats['commission'] += (float)$r['admin_commission'];}
}
include __DIR__ . '/partials/header.php';
?>
<div class="section-title"><h2>Mentor Dashboard</h2><span class="badge">ID: <?= e($_SESSION['user']['public_id']) ?></span></div>
<?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<div class="stats">
    <div class="stat"><p class="muted">Pending Requests</p><h3><?= e((string)$stats['pending']) ?></h3></div>
    <div class="stat"><p class="muted">Active / Finished Sessions</p><h3><?= e((string)$stats['accepted']) ?></h3></div>
    <div class="stat"><p class="muted">Released Earnings</p><h3>$<?= e(number_format($stats['earnings'], 2)) ?></h3></div>
    <div class="stat"><p class="muted">Released Admin Commission</p><h3>$<?= e(number_format($stats['commission'], 2)) ?></h3></div>
</div>
<div class="split-grid">
    <div class="form-card">
        <h3>Mentor profile</h3>
        <form method="post">
            <input type="hidden" name="action" value="save_profile">
            <div class="form-row three">
                <div class="form-group"><label>Highest Degree</label><input type="text" name="degree_title" value="<?= e($profile['degree_title'] ?? '') ?>"></div>
                <div class="form-group"><label>Country Affiliation</label><input type="text" name="country_affiliation" value="<?= e($profile['country_affiliation'] ?? '') ?>"></div>
                <div class="form-group"><label>Years of Experience</label><input type="number" min="0" name="years_experience" value="<?= e($profile['years_experience'] ?? '') ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Expertise Area</label><input type="text" name="expertise_area" value="<?= e($profile['expertise_area'] ?? '') ?>"></div>
                <div class="form-group"><label>Languages Spoken</label><input type="text" name="languages_spoken" value="<?= e($profile['languages_spoken'] ?? '') ?>"></div>
            </div>
            <div class="form-row three">
                <div class="form-group"><label>Minimum Session Fee (USD)</label><input type="number" step="0.01" min="5" max="100" name="min_session_fee" value="<?= e($profile['min_session_fee'] ?? '12.00') ?>"></div>
                <div class="form-group"><label>Maximum Session Fee (USD)</label><input type="number" step="0.01" min="5" max="100" name="max_session_fee" value="<?= e($profile['max_session_fee'] ?? '24.00') ?>"></div>
                <div class="form-group"><label>Default Session Duration</label><select name="default_session_minutes"><option value="30" <?= ($profile['default_session_minutes'] ?? 45)==30?'selected':'' ?>>30 minutes</option><option value="45" <?= ($profile['default_session_minutes'] ?? 45)==45?'selected':'' ?>>45 minutes</option><option value="60" <?= ($profile['default_session_minutes'] ?? 45)==60?'selected':'' ?>>60 minutes</option><option value="90" <?= ($profile['default_session_minutes'] ?? 45)==90?'selected':'' ?>>90 minutes</option></select></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Meeting Platform</label><select name="meeting_platform"><option <?= ($profile['meeting_platform'] ?? '')==='Google Meet'?'selected':'' ?>>Google Meet</option><option <?= ($profile['meeting_platform'] ?? '')==='Zoom'?'selected':'' ?>>Zoom</option><option <?= ($profile['meeting_platform'] ?? '')==='Microsoft Teams'?'selected':'' ?>>Microsoft Teams</option><option <?= ($profile['meeting_platform'] ?? '')==='Other'?'selected':'' ?>>Other</option></select></div>
                <div class="form-group"><label>Bio</label><textarea name="bio"><?= e($profile['bio'] ?? '') ?></textarea></div>
            </div>
            <button class="btn" type="submit">Save mentor profile</button>
        </form>
    </div>
    <div class="card pricing-box">
        <h3>Safe mentor payout model</h3>
        <p class="muted">Students request a session and the payment is marked as reserved first. If you accept, the session moves to held-by-platform status. After completion, admin can release 90% to you and keep 10% commission.</p>
        <ul class="list-clean">
            <li>Set a fee range instead of one fixed high price.</li>
            <li>Add the meeting link after acceptance.</li>
            <li>Rejected sessions show as refunded.</li>
            <li>This reduces off-platform cheating in the DBMS flow.</li>
        </ul>
    </div>
</div>
<div class="section-spacer"></div>
<div class="table-card">
    <h3>Incoming mentorship requests</h3>
    <?php if ($requests): ?><table class="table"><tr><th>Student</th><th>Topic</th><th>Duration / Fee</th><th>Status</th><th>Meeting</th><th>Action</th></tr><?php foreach ($requests as $request): ?><tr><td><?= e($request['student_name']) ?><br><span class="muted"><?= e($request['student_public_id']) ?></span></td><td><?= e($request['topic']) ?><br><span class="muted"><?= e($request['student_note']) ?></span></td><td><?= e($request['session_duration_minutes']) ?> min<br>$<?= e(number_format((float)$request['session_fee'], 2)) ?><br><span class="muted">Admin: $<?= e(number_format((float)$request['admin_commission'], 2)) ?> / You: $<?= e(number_format((float)$request['mentor_earning'], 2)) ?></span></td><td><span class="status <?= e(strtolower(str_replace(' ', '-', $request['request_status']))) ?>"><?= e($request['request_status']) ?></span><br><span class="muted">Payment: <?= e($request['payment_status']) ?></span></td><td><?php if (!empty($request['meeting_link'])): ?><a class="btn secondary small-btn" href="<?= e($request['meeting_link']) ?>" target="_blank"><?= e($request['meeting_platform'] ?: 'Join') ?></a><?php else: ?><span class="muted">No link yet</span><?php endif; ?></td><td><?php if ($request['request_status'] === 'Pending'): ?><form method="post" class="actions"><input type="hidden" name="action" value="update_request"><input type="hidden" name="session_id" value="<?= e($request['id']) ?>"><button class="btn small-btn" type="submit" name="new_status" value="Accepted">Accept</button><button class="btn danger small-btn" type="submit" name="new_status" value="Rejected">Reject</button></form><?php else: ?><div class="stacked-actions"><?php if (in_array($request['request_status'], ['Accepted','Scheduled'], true)): ?><form method="post"><input type="hidden" name="action" value="set_meeting"><input type="hidden" name="session_id" value="<?= e($request['id']) ?>"><input class="compact-input" name="meeting_link" value="<?= e($request['meeting_link'] ?? '') ?>" placeholder="Meeting link"><input type="hidden" name="meeting_platform" value="<?= e($profile['meeting_platform'] ?? 'Google Meet') ?>"><button class="btn secondary small-btn" type="submit">Save link</button></form><form method="post"><input type="hidden" name="action" value="update_request"><input type="hidden" name="session_id" value="<?= e($request['id']) ?>"><button class="btn ghost small-btn" type="submit" name="new_status" value="Completed">Mark completed</button></form><?php else: ?><span class="muted">Already <?= e($request['request_status']) ?></span><?php endif; ?></div><?php endif; ?></td></tr><?php endforeach; ?></table><?php else: ?><div class="empty-state">No requests received yet.</div><?php endif; ?>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
