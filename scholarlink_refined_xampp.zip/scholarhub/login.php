<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/auth.php';
$error = '';
$flash = get_flash();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identity = trim($_POST['identity'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM users WHERE public_id = ? OR email = ? LIMIT 1');
    $stmt->execute([$identity, $identity]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'public_id' => $user['public_id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role'],
        ];
        redirect_to_dashboard();
    } else {
        $error = 'Invalid login ID/email or password.';
    }
}
include __DIR__ . '/partials/header.php';
?>
<div class="auth-wrap form-card">
    <h2>Login to ScholarLink</h2>
    <p class="muted">Use your ScholarLink ID such as <strong>SCL100001</strong>, <strong>MTR100001</strong>, <strong>UNI100001</strong>, or <strong>DNR100001</strong>. Email also works.</p>
    <?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="post">
        <div class="form-group"><label>ScholarLink ID or Email</label><input type="text" name="identity" required></div>
        <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
        <div class="actions">
            <button class="btn" type="submit">Login</button>
            <a class="btn secondary" href="<?= e(url('forgot_password.php')) ?>">Forgot password</a>
        </div>
    </form>
    <p class="muted">Demo admin: ADM100001 / admin123</p>
    <p class="muted">Demo student: SCL100001 / student123!</p>
    <p class="muted">Demo mentor: MTR100001 / mentor123!</p>
    <p class="muted">Demo university: UNI100001 / uni12345!</p>
    <p class="muted">Demo donor: DNR100001 / donor123!</p>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
