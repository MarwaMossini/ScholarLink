<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$candidates = [];
if (!empty($_ENV['SCHOLARLINK_DB'])) {
    $candidates[] = $_ENV['SCHOLARLINK_DB'];
}
$candidates = array_merge($candidates, ['scholarship_platform', 'scholarhub', 'eduspring', 'masomaa']);
$candidates = array_values(array_unique($candidates));

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

$pdo = null;
$lastError = '';
$connectedDb = null;
foreach ($candidates as $db) {
    try {
        $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
        $pdo = new PDO($dsn, $user, $pass, $options);
        $connectedDb = $db;
        break;
    } catch (PDOException $e) {
        $lastError = $e->getMessage();
    }
}

if (!$pdo) {
    exit('Database connection failed. Import the SQL into one of these database names: scholarship_platform, scholarhub, eduspring, or masomaa. You can also set SCHOLARLINK_DB in config/db.php. Details: ' . htmlspecialchars($lastError));
}
?>
