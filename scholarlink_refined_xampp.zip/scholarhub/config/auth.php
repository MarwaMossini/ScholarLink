<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in(): bool { return isset($_SESSION['user']); }
function current_user_role(): ?string { return $_SESSION['user']['role'] ?? null; }
function is_admin(): bool { return current_user_role() === 'admin'; }
function is_student(): bool { return current_user_role() === 'student'; }
function is_mentor(): bool { return current_user_role() === 'mentor'; }
function is_university(): bool { return current_user_role() === 'university'; }
function is_donor(): bool { return current_user_role() === 'donor'; }
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }

function app_base_url(): string {
    static $base = null;
    if ($base !== null) { return $base; }
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    if ($script === '') { return $base = ''; }
    $base = str_contains($script, '/admin/') ? dirname(dirname($script)) : dirname($script);
    if ($base === '/' || $base === '\\' || $base === '.') { $base = ''; }
    return rtrim($base, '/');
}

function url(string $path = ''): string {
    $base = app_base_url();
    $path = ltrim($path, '/');
    return ($base !== '' ? $base : '') . ($path !== '' ? '/' . $path : '');
}

function redirect(string $path): void {
    header('Location: ' . url($path));
    exit;
}

function set_flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array {
    if (!isset($_SESSION['flash'])) { return null; }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

function require_login(): void {
    if (!is_logged_in()) { redirect('login.php'); }
}
function require_admin(): void { if (!is_admin()) { redirect('login.php'); } }
function require_role(string $role): void { if (current_user_role() !== $role) { redirect('login.php'); } }

function redirect_to_dashboard(): void {
    if (!is_logged_in()) { redirect('login.php'); }
    switch (current_user_role()) {
        case 'admin': redirect('admin/dashboard.php');
        case 'mentor': redirect('mentor_dashboard.php');
        case 'university': redirect('university_dashboard.php');
        case 'donor': redirect('donor_dashboard.php');
        default: redirect('dashboard.php');
    }
}
?>
