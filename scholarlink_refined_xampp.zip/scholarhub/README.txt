CampusLynk - XAMPP Ready

SETUP
1. Put folder "scholarhub" inside C:\xampp\htdocs\
2. Start Apache and MySQL in XAMPP
3. Open http://localhost/phpmyadmin
4. Import scholarhub/sql/scholarship_platform.sql
5. Open http://localhost/scholarhub/

DEMO LOGINS
Admin:
- Email: admin@scholarhub.test
- Password: admin123

Demo Student:
- ID: SCL1000
- Password: admin123

Demo Mentor:
- ID: MTR1000
- Password: mentor123!A1

NOTES
- Login accepts CampusLynk ID or email
- New students receive IDs like SCL1001, SCL1002...
- New mentors receive IDs like MTR1002, MTR1003...
- Mentor payment is modeled in the database for DBMS purposes with 10% admin commission
