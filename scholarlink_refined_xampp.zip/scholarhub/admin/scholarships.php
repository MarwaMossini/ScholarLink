<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();
$message = '';
$edit = null;

if (isset($_GET['delete'])) {
    $pdo->prepare('DELETE FROM scholarships WHERE id=?')->execute([(int)$_GET['delete']]);
    header('Location: scholarships.php');
    exit;
}
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM scholarships WHERE id=?');
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [trim($_POST['university_id']), trim($_POST['program_id']), trim($_POST['title']), trim($_POST['country']), trim($_POST['degree_level']), trim($_POST['funding_type']), trim($_POST['scholarship_percentage']), trim($_POST['min_gpa']), trim($_POST['english_doc_required']), trim($_POST['entry_exam_required']), trim($_POST['extracurricular_required']), trim($_POST['language_requirement']), trim($_POST['deadline']), trim($_POST['application_link']), trim($_POST['description'])];
    if (!empty($_POST['id'])) {
        $data[] = (int)$_POST['id'];
        $pdo->prepare('UPDATE scholarships SET university_id=?, program_id=?, title=?, country=?, degree_level=?, funding_type=?, scholarship_percentage=?, min_gpa=?, english_doc_required=?, entry_exam_required=?, extracurricular_required=?, language_requirement=?, deadline=?, application_link=?, description=? WHERE id=?')->execute($data);
        $message = 'Scholarship updated.';
    } else {
        $pdo->prepare('INSERT INTO scholarships (university_id, program_id, title, country, degree_level, funding_type, scholarship_percentage, min_gpa, english_doc_required, entry_exam_required, extracurricular_required, language_requirement, deadline, application_link, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')->execute($data);
        $message = 'Scholarship added.';
    }
}
$universities = $pdo->query('SELECT id, name FROM universities ORDER BY name')->fetchAll();
$programs = $pdo->query('SELECT id, program_name FROM programs ORDER BY program_name')->fetchAll();
$rows = $pdo->query('SELECT s.*, u.name AS university_name, p.program_name FROM scholarships s LEFT JOIN universities u ON s.university_id=u.id LEFT JOIN programs p ON s.program_id=p.id ORDER BY s.id DESC')->fetchAll();
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>Manage Scholarships</h2><a class="btn secondary" href="dashboard.php">Back</a></div>
<?php if ($message): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
<div class="form-card">
    <h3><?= $edit ? 'Edit Scholarship' : 'Add Scholarship' ?></h3>
    <form method="post">
        <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
        <div class="form-row">
            <div class="form-group"><label>University</label><select name="university_id"><?php foreach ($universities as $u): ?><option value="<?= e($u['id']) ?>" <?= (($edit['university_id'] ?? '') == $u['id']) ? 'selected' : '' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>Program</label><select name="program_id"><?php foreach ($programs as $p): ?><option value="<?= e($p['id']) ?>" <?= (($edit['program_id'] ?? '') == $p['id']) ? 'selected' : '' ?>><?= e($p['program_name']) ?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>Title</label><input name="title" value="<?= e($edit['title'] ?? '') ?>" required></div>
            <div class="form-group"><label>Country</label><input name="country" value="<?= e($edit['country'] ?? '') ?>" required></div>
            <div class="form-group"><label>Degree Level</label><input name="degree_level" value="<?= e($edit['degree_level'] ?? '') ?>"></div>
            <div class="form-group"><label>Funding Type</label><select name="funding_type"><option <?= (($edit['funding_type'] ?? '')==='Fully Funded')?'selected':''; ?>>Fully Funded</option><option <?= (($edit['funding_type'] ?? '')==='Partial')?'selected':''; ?>>Partial</option><option <?= (($edit['funding_type'] ?? '')==='Merit-based')?'selected':''; ?>>Merit-based</option></select></div>
            <div class="form-group"><label>Scholarship Percentage</label><input type="number" name="scholarship_percentage" value="<?= e($edit['scholarship_percentage'] ?? '') ?>"></div>
            <div class="form-group"><label>Min GPA</label><input type="number" step="0.01" name="min_gpa" value="<?= e($edit['min_gpa'] ?? '') ?>"></div>
            <div class="form-group"><label>English Doc Required</label><select name="english_doc_required"><option <?= (($edit['english_doc_required'] ?? '')==='Yes')?'selected':''; ?>>Yes</option><option <?= (($edit['english_doc_required'] ?? '')==='No')?'selected':''; ?>>No</option></select></div>
            <div class="form-group"><label>Entry Exam Required</label><select name="entry_exam_required"><option <?= (($edit['entry_exam_required'] ?? '')==='Yes')?'selected':''; ?>>Yes</option><option <?= (($edit['entry_exam_required'] ?? '')==='No')?'selected':''; ?>>No</option></select></div>
            <div class="form-group"><label>Extracurricular Required</label><select name="extracurricular_required"><option <?= (($edit['extracurricular_required'] ?? '')==='Yes')?'selected':''; ?>>Yes</option><option <?= (($edit['extracurricular_required'] ?? '')==='No')?'selected':''; ?>>No</option></select></div>
            <div class="form-group"><label>Language</label><input name="language_requirement" value="<?= e($edit['language_requirement'] ?? '') ?>"></div>
            <div class="form-group"><label>Deadline</label><input type="date" name="deadline" value="<?= e($edit['deadline'] ?? '') ?>"></div>
            <div class="form-group"><label>Application Link</label><input name="application_link" value="<?= e($edit['application_link'] ?? '') ?>"></div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description"><?= e($edit['description'] ?? '') ?></textarea></div>
        <button class="btn" type="submit"><?= $edit ? 'Update Scholarship' : 'Add Scholarship' ?></button>
    </form>
</div>
<div class="table-card" style="margin-top:18px;">
    <table class="table">
        <tr><th>ID</th><th>Scholarship</th><th>University</th><th>Program</th><th>Funding</th><th>%</th><th>GPA</th><th>Actions</th></tr>
        <?php foreach ($rows as $row): ?><tr><td><?= e($row['id']) ?></td><td><?= e($row['title']) ?></td><td><?= e($row['university_name']) ?></td><td><?= e($row['program_name']) ?></td><td><?= e($row['funding_type']) ?></td><td><?= e($row['scholarship_percentage']) ?></td><td><?= e($row['min_gpa']) ?></td><td class="actions"><a class="btn small-btn secondary" href="?edit=<?= e($row['id']) ?>">Edit</a><a class="btn small-btn danger" href="?delete=<?= e($row['id']) ?>" onclick="return confirm('Delete this scholarship?')">Delete</a></td></tr><?php endforeach; ?>
    </table>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>