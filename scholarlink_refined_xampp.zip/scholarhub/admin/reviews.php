<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();
if (isset($_GET['delete'])) {
    $pdo->prepare('DELETE FROM reviews WHERE id=?')->execute([(int)$_GET['delete']]);
    header('Location: reviews.php'); exit;
}
$rows = $pdo->query("SELECT r.*, u.name AS reviewer_name,
CASE
    WHEN r.entity_type='university' THEN (SELECT name FROM universities WHERE id=r.entity_id)
    WHEN r.entity_type='program' THEN (SELECT program_name FROM programs WHERE id=r.entity_id)
    WHEN r.entity_type='scholarship' THEN (SELECT title FROM scholarships WHERE id=r.entity_id)
    WHEN r.entity_type='mentor' THEN (SELECT name FROM users WHERE id=r.entity_id)
END AS entity_name
FROM reviews r JOIN users u ON u.id=r.reviewer_user_id ORDER BY r.created_at DESC")->fetchAll();
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>Manage Reviews</h2><a class="btn secondary" href="dashboard.php">Back</a></div>
<div class="table-card">
<table class="table">
<tr><th>Type</th><th>Item</th><th>Rating</th><th>Comment</th><th>By</th><th>Action</th></tr>
<?php foreach ($rows as $row): ?>
<tr>
<td><?= e($row['entity_type']) ?></td>
<td><?= e($row['entity_name']) ?></td>
<td><?= e($row['rating']) ?>/5</td>
<td><?= e($row['comment']) ?></td>
<td><?= e($row['reviewer_name']) ?></td>
<td><a class="btn danger small-btn" href="?delete=<?= e($row['id']) ?>" onclick="return confirm('Delete review?')">Delete</a></td>
</tr>
<?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>
