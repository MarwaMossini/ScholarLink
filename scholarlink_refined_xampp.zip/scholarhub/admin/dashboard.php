<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();
$stats = [
    'universities' => $pdo->query('SELECT COUNT(*) FROM universities')->fetchColumn(),
    'programs' => $pdo->query('SELECT COUNT(*) FROM programs')->fetchColumn(),
    'scholarships' => $pdo->query('SELECT COUNT(*) FROM scholarships')->fetchColumn(),
    'students' => $pdo->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn(),
    'mentors' => $pdo->query("SELECT COUNT(*) FROM users WHERE role='mentor'")->fetchColumn(),
    'university_accounts' => $pdo->query("SELECT COUNT(*) FROM users WHERE role='university'")->fetchColumn(),
    'donors' => $pdo->query("SELECT COUNT(*) FROM users WHERE role='donor'")->fetchColumn(),
    'applications' => $pdo->query('SELECT COUNT(*) FROM applications')->fetchColumn(),
    'reviews' => $pdo->query('SELECT COUNT(*) FROM reviews')->fetchColumn(),
    'commission' => $pdo->query("SELECT COALESCE(SUM(admin_amount),0) FROM mentor_payments WHERE payment_status='Paid'")->fetchColumn(),
];
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>Admin Dashboard</h2><span class="badge">Platform Control</span></div>
<div class="stats">
    <div class="stat"><p class="muted">Universities</p><h3><?= e((string)$stats['universities']) ?></h3></div>
    <div class="stat"><p class="muted">Programs</p><h3><?= e((string)$stats['programs']) ?></h3></div>
    <div class="stat"><p class="muted">Scholarships</p><h3><?= e((string)$stats['scholarships']) ?></h3></div>
    <div class="stat"><p class="muted">Students</p><h3><?= e((string)$stats['students']) ?></h3></div>
    <div class="stat"><p class="muted">Mentors</p><h3><?= e((string)$stats['mentors']) ?></h3></div>
    <div class="stat"><p class="muted">University Accounts</p><h3><?= e((string)$stats['university_accounts']) ?></h3></div>
    <div class="stat"><p class="muted">Donors</p><h3><?= e((string)$stats['donors']) ?></h3></div>
    <div class="stat"><p class="muted">Applications</p><h3><?= e((string)$stats['applications']) ?></h3></div>
    <div class="stat"><p class="muted">Reviews</p><h3><?= e((string)$stats['reviews']) ?></h3></div>
    <div class="stat"><p class="muted">Paid Commission</p><h3>$<?= e(number_format((float)$stats['commission'], 2)) ?></h3></div>
</div>
<div class="card-grid">
    <div class="card"><h3>Manage Universities</h3><p>Maintain university data and academic requirements.</p><a class="btn" href="universities.php">Open</a></div>
    <div class="card"><h3>Manage Programs</h3><p>Connect programs to universities and degrees.</p><a class="btn" href="programs.php">Open</a></div>
    <div class="card"><h3>Manage Scholarships</h3><p>Control scholarship filters and application details.</p><a class="btn" href="scholarships.php">Open</a></div>
    <div class="card"><h3>Manage Students</h3><p>View and edit student profiles.</p><a class="btn" href="students.php">Open</a></div>
    <div class="card"><h3>Manage Mentors</h3><p>Review mentor profiles, fees, and expertise areas.</p><a class="btn" href="mentors.php">Open</a></div>
    <div class="card"><h3>University Accounts</h3><p>See institution signups and linked records.</p><a class="btn" href="university_accounts.php">Open</a></div>
    <div class="card"><h3>Donor Accounts</h3><p>See scholarship donor signups and funding focus.</p><a class="btn" href="donors.php">Open</a></div>
    <div class="card"><h3>Mentorship Requests</h3><p>Monitor accepted, pending, and rejected sessions.</p><a class="btn" href="mentorships.php">Open</a></div>
    <div class="card"><h3>Payments & Commission</h3><p>Track mentor fee split and admin share.</p><a class="btn" href="payments.php">Open</a></div>
    <div class="card"><h3>Applications</h3><p>Inspect scholarship applications by students.</p><a class="btn" href="applications.php">Open</a></div>
    <div class="card"><h3>Reviews</h3><p>Inspect platform reviews for all entity types.</p><a class="btn" href="reviews.php">Open</a></div>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>