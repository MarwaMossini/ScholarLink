<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();
$message = '';
$edit = null;

if (isset($_GET['delete'])) {
    $pdo->prepare('DELETE FROM universities WHERE id=?')->execute([(int)$_GET['delete']]);
    header('Location: universities.php');
    exit;
}

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM universities WHERE id=?');
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        trim($_POST['name'] ?? ''), trim($_POST['country'] ?? ''), trim($_POST['city'] ?? ''),
        trim($_POST['website'] ?? ''), trim($_POST['ranking'] ?? ''), trim($_POST['description'] ?? ''),
        trim($_POST['language_of_instruction'] ?? ''), trim($_POST['english_requirement'] ?? ''),
        trim($_POST['entry_exam_requirement'] ?? ''), trim($_POST['tuition_fee'] ?? ''), trim($_POST['status'] ?? 'Active')
    ];
    if (!empty($_POST['id'])) {
        $data[] = (int)$_POST['id'];
        $sql = 'UPDATE universities SET name=?, country=?, city=?, website=?, ranking=?, description=?, language_of_instruction=?, english_requirement=?, entry_exam_requirement=?, tuition_fee=?, status=? WHERE id=?';
        $pdo->prepare($sql)->execute($data);
        $message = 'University updated.';
    } else {
        $sql = 'INSERT INTO universities (name, country, city, website, ranking, description, language_of_instruction, english_requirement, entry_exam_requirement, tuition_fee, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        $pdo->prepare($sql)->execute($data);
        $message = 'University added.';
    }
}

$rows = $pdo->query('SELECT * FROM universities ORDER BY id DESC')->fetchAll();
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>Manage Universities</h2><a class="btn secondary" href="dashboard.php">Back</a></div>
<?php if ($message): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
<div class="form-card">
    <h3><?= $edit ? 'Edit University' : 'Add University' ?></h3>
    <form method="post">
        <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
        <div class="form-row">
            <div class="form-group"><label>Name</label><input name="name" value="<?= e($edit['name'] ?? '') ?>" required></div>
            <div class="form-group"><label>Country</label><input name="country" value="<?= e($edit['country'] ?? '') ?>" required></div>
            <div class="form-group"><label>City</label><input name="city" value="<?= e($edit['city'] ?? '') ?>"></div>
            <div class="form-group"><label>Website</label><input name="website" value="<?= e($edit['website'] ?? '') ?>"></div>
            <div class="form-group"><label>Ranking</label><input name="ranking" value="<?= e($edit['ranking'] ?? '') ?>"></div>
            <div class="form-group"><label>Tuition Fee</label><input name="tuition_fee" value="<?= e($edit['tuition_fee'] ?? '') ?>"></div>
            <div class="form-group"><label>Language of Instruction</label><input name="language_of_instruction" value="<?= e($edit['language_of_instruction'] ?? '') ?>"></div>
            <div class="form-group"><label>English Requirement</label><input name="english_requirement" value="<?= e($edit['english_requirement'] ?? '') ?>" placeholder="IELTS/TOEFL required"></div>
            <div class="form-group"><label>Entry Exam Requirement</label><input name="entry_exam_requirement" value="<?= e($edit['entry_exam_requirement'] ?? '') ?>"></div>
            <div class="form-group"><label>Status</label><select name="status"><option <?= (($edit['status'] ?? '')==='Active')?'selected':''; ?>>Active</option><option <?= (($edit['status'] ?? '')==='Inactive')?'selected':''; ?>>Inactive</option></select></div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description"><?= e($edit['description'] ?? '') ?></textarea></div>
        <button class="btn" type="submit"><?= $edit ? 'Update University' : 'Add University' ?></button>
    </form>
</div>
<div class="table-card" style="margin-top:18px;">
    <table class="table">
        <tr><th>ID</th><th>Name</th><th>Country</th><th>Language</th><th>English Requirement</th><th>Status</th><th>Actions</th></tr>
        <?php foreach ($rows as $row): ?>
        <tr>
            <td><?= e($row['id']) ?></td>
            <td><?= e($row['name']) ?></td>
            <td><?= e($row['country']) ?></td>
            <td><?= e($row['language_of_instruction']) ?></td>
            <td><?= e($row['english_requirement']) ?></td>
            <td><?= e($row['status']) ?></td>
            <td class="actions"><a class="btn small-btn secondary" href="?edit=<?= e($row['id']) ?>">Edit</a><a class="btn small-btn danger" href="?delete=<?= e($row['id']) ?>" onclick="return confirm('Delete this university?')">Delete</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>