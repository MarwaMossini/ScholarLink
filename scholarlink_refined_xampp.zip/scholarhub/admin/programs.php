<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();
$message = '';
$edit = null;

if (isset($_GET['delete'])) {
    $pdo->prepare('DELETE FROM programs WHERE id=?')->execute([(int)$_GET['delete']]);
    header('Location: programs.php');
    exit;
}
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM programs WHERE id=?');
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [trim($_POST['university_id']), trim($_POST['program_name']), trim($_POST['degree_level']), trim($_POST['duration']), trim($_POST['tuition_fee']), trim($_POST['language_requirement']), trim($_POST['field_category']), trim($_POST['description'])];
    if (!empty($_POST['id'])) {
        $data[] = (int)$_POST['id'];
        $pdo->prepare('UPDATE programs SET university_id=?, program_name=?, degree_level=?, duration=?, tuition_fee=?, language_requirement=?, field_category=?, description=? WHERE id=?')->execute($data);
        $message = 'Program updated.';
    } else {
        $pdo->prepare('INSERT INTO programs (university_id, program_name, degree_level, duration, tuition_fee, language_requirement, field_category, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')->execute($data);
        $message = 'Program added.';
    }
}
$universities = $pdo->query('SELECT id, name FROM universities ORDER BY name')->fetchAll();
$rows = $pdo->query('SELECT p.*, u.name AS university_name FROM programs p JOIN universities u ON p.university_id=u.id ORDER BY p.id DESC')->fetchAll();
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>Manage Programs</h2><a class="btn secondary" href="dashboard.php">Back</a></div>
<?php if ($message): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
<div class="form-card">
    <h3><?= $edit ? 'Edit Program' : 'Add Program' ?></h3>
    <form method="post">
        <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
        <div class="form-row">
            <div class="form-group"><label>University</label><select name="university_id" required><?php foreach ($universities as $u): ?><option value="<?= e($u['id']) ?>" <?= (($edit['university_id'] ?? '') == $u['id']) ? 'selected' : '' ?>><?= e($u['name']) ?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>Program Name</label><input name="program_name" value="<?= e($edit['program_name'] ?? '') ?>" required></div>
            <div class="form-group"><label>Degree Level</label><input name="degree_level" value="<?= e($edit['degree_level'] ?? '') ?>"></div>
            <div class="form-group"><label>Duration</label><input name="duration" value="<?= e($edit['duration'] ?? '') ?>"></div>
            <div class="form-group"><label>Tuition Fee</label><input name="tuition_fee" value="<?= e($edit['tuition_fee'] ?? '') ?>"></div>
            <div class="form-group"><label>Language Requirement</label><input name="language_requirement" value="<?= e($edit['language_requirement'] ?? '') ?>"></div>
            <div class="form-group"><label>Field Category</label><input name="field_category" value="<?= e($edit['field_category'] ?? '') ?>"></div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description"><?= e($edit['description'] ?? '') ?></textarea></div>
        <button class="btn" type="submit"><?= $edit ? 'Update Program' : 'Add Program' ?></button>
    </form>
</div>
<div class="table-card" style="margin-top:18px;">
    <table class="table">
        <tr><th>ID</th><th>Program</th><th>University</th><th>Degree</th><th>Language</th><th>Actions</th></tr>
        <?php foreach ($rows as $row): ?><tr><td><?= e($row['id']) ?></td><td><?= e($row['program_name']) ?></td><td><?= e($row['university_name']) ?></td><td><?= e($row['degree_level']) ?></td><td><?= e($row['language_requirement']) ?></td><td class="actions"><a class="btn small-btn secondary" href="?edit=<?= e($row['id']) ?>">Edit</a><a class="btn small-btn danger" href="?delete=<?= e($row['id']) ?>" onclick="return confirm('Delete this program?')">Delete</a></td></tr><?php endforeach; ?>
    </table>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>