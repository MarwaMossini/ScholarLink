<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();
$message=''; $edit=null;
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM users WHERE id=? AND role='mentor'")->execute([(int)$_GET['delete']]);
    header('Location: mentors.php'); exit;
}
if (isset($_GET['edit'])) {
    $stmt=$pdo->prepare("SELECT u.*, mp.* FROM users u JOIN mentor_profiles mp ON mp.user_id=u.id WHERE u.id=? AND u.role='mentor'");
    $stmt->execute([(int)$_GET['edit']]); $edit=$stmt->fetch();
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $id=(int)$_POST['id'];
    $minFee=(float)($_POST['min_session_fee'] ?? 0);
    $maxFee=(float)($_POST['max_session_fee'] ?? 0);
    $pdo->prepare('UPDATE users SET name=?, email=? WHERE id=? AND role="mentor"')->execute([trim($_POST['name']), trim($_POST['email']), $id]);
    $pdo->prepare('UPDATE mentor_profiles SET degree_title=?, country_affiliation=?, expertise_area=?, hourly_fee=?, min_session_fee=?, max_session_fee=?, default_session_minutes=?, meeting_platform=?, languages_spoken=?, years_experience=?, bio=? WHERE user_id=?')
        ->execute([trim($_POST['degree_title']), trim($_POST['country_affiliation']), trim($_POST['expertise_area']), $minFee, $minFee, $maxFee, (int)($_POST['default_session_minutes'] ?? 45), trim($_POST['meeting_platform']), trim($_POST['languages_spoken']), trim($_POST['years_experience']) ?: 0, trim($_POST['bio']), $id]);
    $message='Mentor updated.';
}
$rows=$pdo->query("SELECT u.id,u.public_id,u.name,u.email,mp.expertise_area,mp.min_session_fee,mp.max_session_fee,mp.default_session_minutes,mp.country_affiliation FROM users u JOIN mentor_profiles mp ON mp.user_id=u.id WHERE u.role='mentor' ORDER BY u.id DESC")->fetchAll();
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>Manage Mentors</h2><a class="btn secondary" href="dashboard.php">Back</a></div>
<?php if ($message): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
<?php if ($edit): ?>
<div class="form-card">
    <h3>Edit Mentor</h3>
    <form method="post">
        <input type="hidden" name="id" value="<?= e($edit['id']) ?>">
        <div class="form-row three">
            <div class="form-group"><label>Name</label><input name="name" value="<?= e($edit['name']) ?>"></div>
            <div class="form-group"><label>Email</label><input name="email" value="<?= e($edit['email']) ?>"></div>
            <div class="form-group"><label>Highest Degree</label><input name="degree_title" value="<?= e($edit['degree_title']) ?>"></div>
        </div>
        <div class="form-row three">
            <div class="form-group"><label>Country</label><input name="country_affiliation" value="<?= e($edit['country_affiliation']) ?>"></div>
            <div class="form-group"><label>Expertise</label><input name="expertise_area" value="<?= e($edit['expertise_area']) ?>"></div>
            <div class="form-group"><label>Duration</label><select name="default_session_minutes"><option value="30" <?= ($edit['default_session_minutes'] ?? 45)==30?'selected':'' ?>>30</option><option value="45" <?= ($edit['default_session_minutes'] ?? 45)==45?'selected':'' ?>>45</option><option value="60" <?= ($edit['default_session_minutes'] ?? 45)==60?'selected':'' ?>>60</option><option value="90" <?= ($edit['default_session_minutes'] ?? 45)==90?'selected':'' ?>>90</option></select></div>
        </div>
        <div class="form-row three">
            <div class="form-group"><label>Min Fee</label><input name="min_session_fee" value="<?= e($edit['min_session_fee']) ?>"></div>
            <div class="form-group"><label>Max Fee</label><input name="max_session_fee" value="<?= e($edit['max_session_fee']) ?>"></div>
            <div class="form-group"><label>Meeting Platform</label><input name="meeting_platform" value="<?= e($edit['meeting_platform']) ?>"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Languages</label><input name="languages_spoken" value="<?= e($edit['languages_spoken']) ?>"></div>
            <div class="form-group"><label>Years Experience</label><input name="years_experience" value="<?= e($edit['years_experience']) ?>"></div>
        </div>
        <div class="form-group"><label>Bio</label><textarea name="bio"><?= e($edit['bio']) ?></textarea></div>
        <button class="btn">Save</button>
    </form>
</div>
<?php endif; ?>
<div class="table-card section-spacer">
<table class="table"><tr><th>ID</th><th>Mentor</th><th>Country</th><th>Expertise</th><th>Fee Range</th><th>Default Duration</th><th>Action</th></tr>
<?php foreach($rows as $row): ?>
<tr>
    <td><?= e($row['public_id']) ?></td>
    <td><?= e($row['name']) ?><br><span class="muted"><?= e($row['email']) ?></span></td>
    <td><?= e($row['country_affiliation']) ?></td>
    <td><?= e($row['expertise_area']) ?></td>
    <td>$<?= e(number_format((float)$row['min_session_fee'],2)) ?> - $<?= e(number_format((float)$row['max_session_fee'],2)) ?></td>
    <td><?= e($row['default_session_minutes']) ?> min</td>
    <td class="actions"><a class="btn secondary small-btn" href="?edit=<?= e($row['id']) ?>">Edit</a><a class="btn danger small-btn" href="?delete=<?= e($row['id']) ?>" onclick="return confirm('Delete this mentor?')">Delete</a></td>
</tr>
<?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>
