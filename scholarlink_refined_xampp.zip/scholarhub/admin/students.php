<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();
$message = '';
$edit = null;

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM users WHERE id = ? AND role='student'")->execute([(int)$_GET['delete']]);
    header('Location: students.php');
    exit;
}

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT u.*, sp.* FROM users u LEFT JOIN student_profiles sp ON sp.user_id=u.id WHERE u.id=? AND u.role='student'");
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['id'];
    $pdo->prepare('UPDATE users SET name=?, email=? WHERE id=? AND role="student"')->execute([trim($_POST['name']), trim($_POST['email']), $id]);
    $pdo->prepare('UPDATE student_profiles SET country=?, academic_level=?, gpa=?, field_of_interest=?, preferred_country=?, preferred_language=? WHERE user_id=?')
        ->execute([trim($_POST['country']), trim($_POST['academic_level']), trim($_POST['gpa']) ?: null, trim($_POST['field_of_interest']), trim($_POST['preferred_country']), trim($_POST['preferred_language']), $id]);
    $message = 'Student updated.';
}

$rows = $pdo->query("SELECT u.id, u.public_id, u.name, u.email, sp.country, sp.academic_level, sp.gpa FROM users u LEFT JOIN student_profiles sp ON sp.user_id=u.id WHERE u.role='student' ORDER BY u.id DESC")->fetchAll();
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>Manage Students</h2><a class="btn secondary" href="dashboard.php">Back</a></div>
<?php if ($message): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
<?php if ($edit): ?>
<div class="form-card">
    <h3>Edit Student</h3>
    <form method="post">
        <input type="hidden" name="id" value="<?= e($edit['id']) ?>">
        <div class="form-row three">
            <div class="form-group"><label>Name</label><input name="name" value="<?= e($edit['name']) ?>"></div>
            <div class="form-group"><label>Email</label><input name="email" value="<?= e($edit['email']) ?>"></div>
            <div class="form-group"><label>Country</label><input name="country" value="<?= e($edit['country']) ?>"></div>
        </div>
        <div class="form-row three">
            <div class="form-group"><label>Academic Level</label><input name="academic_level" value="<?= e($edit['academic_level']) ?>"></div>
            <div class="form-group"><label>GPA</label><input name="gpa" value="<?= e($edit['gpa']) ?>"></div>
            <div class="form-group"><label>Preferred Country</label><input name="preferred_country" value="<?= e($edit['preferred_country']) ?>"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Field of Interest</label><input name="field_of_interest" value="<?= e($edit['field_of_interest']) ?>"></div>
            <div class="form-group"><label>Preferred Language</label><input name="preferred_language" value="<?= e($edit['preferred_language']) ?>"></div>
        </div>
        <button class="btn" type="submit">Save changes</button>
    </form>
</div>
<?php endif; ?>
<div class="table-card section-spacer">
    <table class="table">
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Country</th><th>Academic</th><th>GPA</th><th>Actions</th></tr>
        <?php foreach ($rows as $row): ?>
        <tr>
            <td><?= e($row['public_id']) ?></td>
            <td><?= e($row['name']) ?></td>
            <td><?= e($row['email']) ?></td>
            <td><?= e($row['country']) ?></td>
            <td><?= e($row['academic_level']) ?></td>
            <td><?= e($row['gpa']) ?></td>
            <td class="actions"><a class="btn secondary small-btn" href="?edit=<?= e($row['id']) ?>">Edit</a><a class="btn danger small-btn" href="?delete=<?= e($row['id']) ?>" onclick="return confirm('Delete this student?')">Delete</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>
