<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();
if (isset($_GET['delete'])) { $pdo->prepare("DELETE FROM users WHERE id=? AND role='university'")->execute([(int)$_GET['delete']]); header('Location: university_accounts.php'); exit; }
$rows = $pdo->query("SELECT u.id, u.public_id, u.name, u.email, ua.institution_name, ua.country, ua.website, (SELECT COUNT(*) FROM universities uni WHERE uni.owner_user_id=u.id) AS university_records FROM users u LEFT JOIN university_accounts ua ON ua.user_id=u.id WHERE u.role='university' ORDER BY u.id DESC")->fetchAll();
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>University Accounts</h2><a class="btn secondary" href="dashboard.php">Back</a></div>
<div class="table-card"><table class="table"><tr><th>ID</th><th>Institution</th><th>Contact</th><th>Country</th><th>Website</th><th>Records</th><th>Action</th></tr><?php foreach($rows as $row): ?><tr><td><?= e($row['public_id']) ?></td><td><?= e($row['institution_name']) ?></td><td><?= e($row['name']) ?><br><span class="muted"><?= e($row['email']) ?></span></td><td><?= e($row['country']) ?></td><td><?= e($row['website']) ?></td><td><?= e($row['university_records']) ?></td><td><a class="btn danger small-btn" href="?delete=<?= e($row['id']) ?>" onclick="return confirm('Delete this university account?')">Delete</a></td></tr><?php endforeach; ?></table></div>
<?php include __DIR__ . '/../partials/footer.php'; ?>