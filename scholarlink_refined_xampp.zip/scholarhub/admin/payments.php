<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'release') {
    $sessionId = (int)($_POST['session_id'] ?? 0);
    $pdo->prepare('UPDATE mentor_payments SET payment_status=? WHERE session_id=?')->execute(['Released', $sessionId]);
    $pdo->prepare('UPDATE mentorship_sessions SET payment_status=? WHERE id=?')->execute(['Released to mentor', $sessionId]);
    set_flash('success', 'Mentor payout released.');
    redirect('admin/payments.php');
}
$flash = get_flash();
$rows = $pdo->query("SELECT mp.*, ms.payment_status AS session_payment_status, ms.request_status, su.name AS student_name, mu.name AS mentor_name
FROM mentor_payments mp
JOIN mentorship_sessions ms ON ms.id = mp.session_id
JOIN users su ON su.id = ms.student_user_id
JOIN users mu ON mu.id = ms.mentor_user_id
ORDER BY mp.created_at DESC")->fetchAll();
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>Payments & Commission</h2><a class="btn secondary" href="dashboard.php">Back</a></div>
<?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<div class="table-card">
<table class="table">
<tr><th>Student</th><th>Mentor</th><th>Total</th><th>Admin Share</th><th>Mentor Share</th><th>Method</th><th>Status</th><th>Action</th></tr>
<?php foreach ($rows as $row): ?>
<tr>
<td><?= e($row['student_name']) ?></td>
<td><?= e($row['mentor_name']) ?></td>
<td>$<?= e(number_format((float)$row['total_amount'],2)) ?></td>
<td>$<?= e(number_format((float)$row['admin_amount'],2)) ?></td>
<td>$<?= e(number_format((float)$row['mentor_amount'],2)) ?></td>
<td><?= e($row['payment_method']) ?></td>
<td><span class="status <?= e(strtolower(str_replace(' ', '-', $row['session_payment_status']))) ?>"><?= e($row['session_payment_status']) ?></span><br><span class="muted">Payment row: <?= e($row['payment_status']) ?> / Session: <?= e($row['request_status']) ?></span></td>
<td><?php if ($row['payment_status'] === 'Held' && $row['request_status'] === 'Completed'): ?><form method="post"><input type="hidden" name="action" value="release"><input type="hidden" name="session_id" value="<?= e($row['session_id']) ?>"><button class="btn small-btn">Release payout</button></form><?php else: ?><span class="muted">No action</span><?php endif; ?></td>
</tr>
<?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>
