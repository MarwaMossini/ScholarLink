<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();
if (isset($_GET['delete'])) { $pdo->prepare("DELETE FROM users WHERE id=? AND role='donor'")->execute([(int)$_GET['delete']]); header('Location: donors.php'); exit; }
$rows = $pdo->query("SELECT u.id, u.public_id, u.name, u.email, dp.organization_name, dp.country, dp.focus_area, (SELECT COUNT(*) FROM scholarships s WHERE s.donor_user_id=u.id) AS scholarships_count FROM users u LEFT JOIN donor_profiles dp ON dp.user_id=u.id WHERE u.role='donor' ORDER BY u.id DESC")->fetchAll();
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>Donor Accounts</h2><a class="btn secondary" href="dashboard.php">Back</a></div>
<div class="table-card"><table class="table"><tr><th>ID</th><th>Organization</th><th>Contact</th><th>Country</th><th>Focus</th><th>Scholarships</th><th>Action</th></tr><?php foreach($rows as $row): ?><tr><td><?= e($row['public_id']) ?></td><td><?= e($row['organization_name']) ?></td><td><?= e($row['name']) ?><br><span class="muted"><?= e($row['email']) ?></span></td><td><?= e($row['country']) ?></td><td><?= e($row['focus_area']) ?></td><td><?= e($row['scholarships_count']) ?></td><td><a class="btn danger small-btn" href="?delete=<?= e($row['id']) ?>" onclick="return confirm('Delete this donor account?')">Delete</a></td></tr><?php endforeach; ?></table></div>
<?php include __DIR__ . '/../partials/footer.php'; ?>