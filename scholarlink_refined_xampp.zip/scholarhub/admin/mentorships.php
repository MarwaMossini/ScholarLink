<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();
$rows = $pdo->query("SELECT ms.*, su.name AS student_name, su.public_id AS student_public_id, mu.name AS mentor_name, mu.public_id AS mentor_public_id
FROM mentorship_sessions ms
JOIN users su ON su.id=ms.student_user_id
JOIN users mu ON mu.id=ms.mentor_user_id
ORDER BY ms.created_at DESC")->fetchAll();
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>Mentorship Requests</h2><a class="btn secondary" href="dashboard.php">Back</a></div>
<div class="table-card">
<table class="table">
<tr><th>Student</th><th>Mentor</th><th>Topic</th><th>Fee Split</th><th>Status</th></tr>
<?php foreach ($rows as $row): ?>
<tr>
<td><?= e($row['student_name']) ?><br><span class="muted"><?= e($row['student_public_id']) ?></span></td>
<td><?= e($row['mentor_name']) ?><br><span class="muted"><?= e($row['mentor_public_id']) ?></span></td>
<td><?= e($row['topic']) ?><br><span class="muted"><?= e($row['preferred_session_date']) ?></span></td>
<td>Total: $<?= e(number_format((float)$row['session_fee'],2)) ?><br><span class="muted">Admin <?= e(number_format((float)$row['admin_commission'],2)) ?> / Mentor <?= e(number_format((float)$row['mentor_earning'],2)) ?></span></td>
<td><span class="status <?= strtolower($row['request_status']) ?>"><?= e($row['request_status']) ?></span><br><span class="muted">Payment: <?= e($row['payment_status']) ?></span></td>
</tr>
<?php endforeach; ?>
</table>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>
