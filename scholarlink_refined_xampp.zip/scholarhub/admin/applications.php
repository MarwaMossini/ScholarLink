<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_admin();
$rows = $pdo->query("SELECT a.*, su.name AS student_name, su.public_id AS student_id, s.title, p.program_name, u.name AS university_name, d.name AS donor_name
FROM applications a
JOIN users su ON su.id=a.student_user_id
LEFT JOIN scholarships s ON s.id=a.scholarship_id
LEFT JOIN programs p ON p.id=a.program_id
LEFT JOIN universities u ON u.id=s.university_id
LEFT JOIN users d ON d.id=s.donor_user_id
ORDER BY a.created_at DESC")->fetchAll();
include __DIR__ . '/../partials/header.php';
?>
<div class="section-title"><h2>Scholarship Applications</h2><a class="btn secondary" href="dashboard.php">Back</a></div>
<div class="table-card"><table class="table"><tr><th>Student</th><th>Scholarship</th><th>Program</th><th>University</th><th>Donor</th><th>Status</th></tr><?php foreach($rows as $row): ?><tr><td><?= e($row['student_name']) ?><br><span class="muted"><?= e($row['student_id']) ?></span></td><td><?= e($row['title']) ?></td><td><?= e($row['program_name']) ?></td><td><?= e($row['university_name']) ?></td><td><?= e($row['donor_name']) ?></td><td><span class="status <?= strtolower($row['status']) ?>"><?= e($row['status']) ?></span></td></tr><?php endforeach; ?></table></div>
<?php include __DIR__ . '/../partials/footer.php'; ?>