<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/auth.php';
$error = '';
$message = '';

function strong_password(string $password): bool {
    return (bool)preg_match('/^(?=(?:.*[A-Za-z]){5,})(?=.*\d)(?=.*[^A-Za-z\d]).{7,}$/', $password);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identity = trim($_POST['identity'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    if ($identity === '' || $password === '' || $confirm === '') {
        $error = 'Please complete all fields.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (!strong_password($password)) {
        $error = 'New password must include at least 5 letters, 1 number, and 1 symbol.';
    } else {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE public_id = ? OR email = ? LIMIT 1');
        $stmt->execute([$identity, $identity]);
        $user = $stmt->fetch();
        if (!$user) {
            $error = 'Account not found.';
        } else {
            $pdo->prepare('UPDATE users SET password=? WHERE id=?')->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
            set_flash('success', 'Password updated. You can login now.');
            redirect('login.php');
        }
    }
}
include __DIR__ . '/partials/header.php';
?>
<div class="auth-wrap form-card">
    <h2>Forgot password</h2>
    <p class="muted">For this DBMS demo, reset your password by entering your ScholarLink ID or email and setting a new password.</p>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <?php if ($message): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
    <form method="post">
        <div class="form-group"><label>ScholarLink ID or Email</label><input type="text" name="identity" required></div>
        <div class="form-row">
            <div class="form-group"><label>New Password</label><input type="password" name="password" required></div>
            <div class="form-group"><label>Confirm New Password</label><input type="password" name="confirm_password" required></div>
        </div>
        <button class="btn" type="submit">Reset password</button>
    </form>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
