<?php
require_once __DIR__ . '/config/auth.php';
$data = $_SESSION['signup_success'] ?? null;
if (!$data) { redirect('signup.php'); }
unset($_SESSION['signup_success']);
include __DIR__ . '/partials/header.php';
?>
<div class="auth-wrap form-card success-screen">
    <span class="lead-tag">Account created</span>
    <h2>Welcome to ScholarLink</h2>
    <p class="muted">Your account is ready. Keep this ID safe because you can use it to login on any device.</p>
    <div class="success-id-box">
        <div><span class="muted">ScholarLink ID</span><h3><?= e($data['id']) ?></h3></div>
        <div><span class="muted">Role</span><h3><?= e(ucfirst($data['role'])) ?></h3></div>
    </div>
    <div class="actions">
        <a class="btn" href="<?= e(url('login.php')) ?>">Go to login</a>
        <a class="btn secondary" href="<?= e(url('index.php')) ?>">Back to home</a>
    </div>
</div>
<?php include __DIR__ . '/partials/footer.php'; ?>
