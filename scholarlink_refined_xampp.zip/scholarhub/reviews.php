<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/auth.php';
$filter = $_GET['type'] ?? '';
$sql = "SELECT r.*, u.name AS reviewer_name,
CASE
    WHEN r.entity_type='university' THEN (SELECT name FROM universities WHERE id=r.entity_id)
    WHEN r.entity_type='program' THEN (SELECT program_name FROM programs WHERE id=r.entity_id)
    WHEN r.entity_type='scholarship' THEN (SELECT title FROM scholarships WHERE id=r.entity_id)
    WHEN r.entity_type='mentor' THEN (SELECT CONCAT(name, ' (', public_id, ')') FROM users WHERE id=r.entity_id)
END AS entity_name
FROM reviews r JOIN users u ON u.id=r.reviewer_user_id WHERE 1=1";
$params=[];
if (in_array($filter, ['university','program','scholarship','mentor'], true)) { $sql .= ' AND r.entity_type=?'; $params[]=$filter; }
$sql .= ' ORDER BY r.created_at DESC';
$stmt = $pdo->prepare($sql); $stmt->execute($params); $reviews=$stmt->fetchAll();
include __DIR__ . '/partials/header.php';
?>
<div class="form-card">
    <div class="section-title"><h2>Community reviews</h2><span class="badge">Universities • Programs • Scholarships • Mentors</span></div>
    <div class="pill-list">
        <a class="pill" href="reviews.php">All</a>
        <a class="pill" href="reviews.php?type=university">Universities</a>
        <a class="pill" href="reviews.php?type=program">Programs</a>
        <a class="pill" href="reviews.php?type=scholarship">Scholarships</a>
        <a class="pill" href="reviews.php?type=mentor">Mentors</a>
    </div>
</div>
<div class="card-grid">
<?php foreach($reviews as $review): ?>
<div class="card"><div class="section-title"><h3><?= e(ucfirst($review['entity_type'])) ?></h3><span class="badge"><?= e($review['entity_name']) ?></span></div><div class="review-stars"><?= str_repeat('★', (int)$review['rating']) ?><?= str_repeat('☆', 5 - (int)$review['rating']) ?></div><p><?= e($review['comment']) ?></p><p class="muted">By <?= e($review['reviewer_name']) ?> • <?= e($review['created_at']) ?></p></div>
<?php endforeach; ?>
</div>
<?php if (!$reviews): ?><div class="empty-state section-spacer">No reviews yet.</div><?php endif; ?>
<?php include __DIR__ . '/partials/footer.php'; ?>