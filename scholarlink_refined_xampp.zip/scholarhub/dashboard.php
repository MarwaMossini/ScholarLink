<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/auth.php';
require_login();
if (!is_student()) { redirect_to_dashboard(); }

$userId = (int)$_SESSION['user']['id'];
$error = '';
$flash = get_flash();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_profile') {
    $englishProof = trim($_POST['english_proof_status'] ?? '');
    $entryExam = trim($_POST['entry_exam_status'] ?? '');
    $englishOther = trim($_POST['english_test_other'] ?? '');
    $examOther = trim($_POST['entry_exam_other'] ?? '');
    if ($englishProof === 'Other' && $englishOther !== '') { $englishProof = 'Other: ' . $englishOther; }
    if ($entryExam === 'Other' && $examOther !== '') { $entryExam = 'Other: ' . $examOther; }

    $stmt = $pdo->prepare('UPDATE student_profiles SET country=?, academic_level=?, gpa=?, field_of_interest=?, preferred_country=?, preferred_language=?, english_proof_status=?, english_test_other=?, entry_exam_status=?, entry_exam_other=?, extracurriculars=?, extracurricular_level=?, budget_range=?, target_degree=?, target_intake=? WHERE user_id=?');
    $stmt->execute([
        trim($_POST['country'] ?? ''),
        trim($_POST['academic_level'] ?? ''),
        trim($_POST['gpa'] ?? '') !== '' ? trim($_POST['gpa']) : null,
        trim($_POST['field_of_interest'] ?? ''),
        trim($_POST['preferred_country'] ?? ''),
        trim($_POST['preferred_language'] ?? ''),
        $englishProof,
        $englishOther,
        $entryExam,
        $examOther,
        trim($_POST['extracurriculars'] ?? ''),
        trim($_POST['extracurricular_level'] ?? ''),
        trim($_POST['budget_range'] ?? ''),
        trim($_POST['target_degree'] ?? ''),
        trim($_POST['target_intake'] ?? ''),
        $userId
    ]);
    set_flash('success', 'Profile updated.');
    redirect('dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'apply') {
    $scholarshipId = (int)($_POST['scholarship_id'] ?? 0);
    $programId = (int)($_POST['program_id'] ?? 0);
    $check = $pdo->prepare('SELECT id FROM applications WHERE student_user_id=? AND scholarship_id=?');
    $check->execute([$userId, $scholarshipId]);
    if (!$check->fetch()) {
        $pdo->prepare('INSERT INTO applications (student_user_id, scholarship_id, program_id, status) VALUES (?, ?, ?, ?)')->execute([$userId, $scholarshipId, $programId ?: null, 'Pending']);
        set_flash('success', 'Application saved to your dashboard.');
    } else {
        set_flash('error', 'You already applied to this scholarship.');
    }
    redirect('dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'request_session') {
    $mentorId = (int)($_POST['mentor_id'] ?? 0);
    $topic = trim($_POST['topic'] ?? '');
    $preferredDate = trim($_POST['preferred_date'] ?? '');
    $paymentMethod = trim($_POST['payment_method'] ?? 'Card via platform');
    $minutes = (int)($_POST['session_duration_minutes'] ?? 45);
    $requestedFee = (float)($_POST['requested_fee'] ?? 0);
    $studentNote = trim($_POST['student_note'] ?? '');

    $mentor = $pdo->prepare('SELECT min_session_fee, max_session_fee, meeting_platform FROM mentor_profiles WHERE user_id = ?');
    $mentor->execute([$mentorId]);
    $mentorRow = $mentor->fetch();

    if (!$mentorRow) {
        $error = 'Mentor not found.';
    } elseif ($requestedFee < (float)$mentorRow['min_session_fee'] || $requestedFee > (float)$mentorRow['max_session_fee']) {
        $error = 'Requested fee must be within the mentor range.';
    } else {
        $adminCommission = round($requestedFee * 0.10, 2);
        $mentorEarning = round($requestedFee - $adminCommission, 2);
        $pdo->prepare('INSERT INTO mentorship_sessions (student_user_id, mentor_user_id, topic, preferred_session_date, session_duration_minutes, session_fee, admin_commission, mentor_earning, payment_method, payment_status, request_status, meeting_platform, student_note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$userId, $mentorId, $topic, $preferredDate ?: null, $minutes, $requestedFee, $adminCommission, $mentorEarning, $paymentMethod, 'Reserved by platform', 'Pending', $mentorRow['meeting_platform'] ?: 'Google Meet', $studentNote]);
        $sessionId = (int)$pdo->lastInsertId();
        $pdo->prepare('INSERT INTO mentor_payments (session_id, total_amount, admin_amount, mentor_amount, payment_method, payment_status) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$sessionId, $requestedFee, $adminCommission, $mentorEarning, $paymentMethod, 'Reserved']);
        set_flash('success', 'Mentor request sent. Payment is marked as reserved by the platform until the session is finished.');
        redirect('dashboard.php');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'submit_review') {
    $entityType = $_POST['entity_type'] ?? '';
    $entityId = (int)($_POST['entity_id'] ?? 0);
    $rating = (int)($_POST['rating'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');
    if (in_array($entityType, ['university','program','scholarship','mentor'], true) && $entityId > 0 && $rating >= 1 && $rating <= 5) {
        $pdo->prepare('INSERT INTO reviews (reviewer_user_id, entity_type, entity_id, rating, comment) VALUES (?, ?, ?, ?, ?)')->execute([$userId, $entityType, $entityId, $rating, $comment]);
        set_flash('success', 'Review submitted.');
        redirect('dashboard.php');
    }
    $error = 'Please complete the review fields correctly.';
}

$profileStmt = $pdo->prepare('SELECT * FROM student_profiles WHERE user_id = ?');
$profileStmt->execute([$userId]);
$profile = $profileStmt->fetch();

$preferredCountry = trim($profile['preferred_country'] ?? '');
$preferredLanguage = trim($profile['preferred_language'] ?? '');
$targetDegree = trim($profile['target_degree'] ?? '');
$gpa = trim((string)($profile['gpa'] ?? ''));
$field = trim($profile['field_of_interest'] ?? '');
$recommendedStmt = $pdo->prepare("SELECT s.id, s.program_id, s.title, u.name AS university_name, p.program_name, s.country, s.funding_type, s.scholarship_percentage, s.language_requirement, s.deadline, s.application_link
FROM scholarships s
LEFT JOIN universities u ON s.university_id = u.id
LEFT JOIN programs p ON s.program_id = p.id
WHERE (?='' OR s.country LIKE ?)
AND (?='' OR s.language_requirement LIKE ?)
AND (?='' OR s.degree_level LIKE ?)
AND (?='' OR s.min_gpa IS NULL OR s.min_gpa <= ?)
AND (?='' OR p.program_name LIKE ? OR p.field_category LIKE ?)
ORDER BY s.scholarship_percentage DESC, s.deadline ASC LIMIT 6");
$recommendedStmt->execute([$preferredCountry, "%$preferredCountry%", $preferredLanguage, "%$preferredLanguage%", $targetDegree, "%$targetDegree%", $gpa, $gpa, $field, "%$field%", "%$field%"]);
$recommended = $recommendedStmt->fetchAll();

$mentors = $pdo->query("SELECT u.id, u.public_id, u.name, mp.degree_title, mp.country_affiliation, mp.expertise_area, mp.min_session_fee, mp.max_session_fee, mp.default_session_minutes, mp.languages_spoken, mp.years_experience,
(SELECT ROUND(AVG(rating),1) FROM reviews WHERE entity_type='mentor' AND entity_id=u.id) AS avg_rating
FROM users u JOIN mentor_profiles mp ON mp.user_id=u.id WHERE u.role='mentor' ORDER BY mp.min_session_fee ASC, u.name ASC")->fetchAll();

$sessionsStmt = $pdo->prepare("SELECT ms.*, u.name AS mentor_name, u.public_id AS mentor_public_id FROM mentorship_sessions ms JOIN users u ON u.id=ms.mentor_user_id WHERE ms.student_user_id=? ORDER BY ms.created_at DESC");
$sessionsStmt->execute([$userId]);
$sessions = $sessionsStmt->fetchAll();

$applicationsStmt = $pdo->prepare("SELECT a.*, s.title, u.name AS university_name, p.program_name FROM applications a
LEFT JOIN scholarships s ON s.id=a.scholarship_id
LEFT JOIN programs p ON p.id=a.program_id
LEFT JOIN universities u ON u.id=s.university_id
WHERE a.student_user_id=? ORDER BY a.created_at DESC");
$applicationsStmt->execute([$userId]);
$applications = $applicationsStmt->fetchAll();

$reviewEntities = [
    'universities' => $pdo->query('SELECT id, name FROM universities ORDER BY name LIMIT 60')->fetchAll(),
    'programs' => $pdo->query('SELECT id, program_name AS name FROM programs ORDER BY program_name LIMIT 60')->fetchAll(),
    'scholarships' => $pdo->query('SELECT id, title AS name FROM scholarships ORDER BY title LIMIT 60')->fetchAll(),
    'mentors' => $pdo->query("SELECT u.id, CONCAT(u.name, ' (', u.public_id, ')') AS name FROM users u WHERE u.role='mentor' ORDER BY u.name")->fetchAll(),
];

include __DIR__ . '/partials/header.php';
$englishCurrent = $profile['english_proof_status'] ?? '';
$entryCurrent = $profile['entry_exam_status'] ?? '';
$englishChoice = (str_starts_with((string)$englishCurrent, 'Other:')) ? 'Other' : $englishCurrent;
$entryChoice = (str_starts_with((string)$entryCurrent, 'Other:')) ? 'Other' : $entryCurrent;
?>
<div class="section-title"><h2>Student Dashboard</h2><span class="badge">ID: <?= e($_SESSION['user']['public_id']) ?></span></div>
<?php if ($flash): ?><div class="alert <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<div class="split-grid">
    <div class="form-card">
        <h3>My profile</h3>
        <form method="post">
            <input type="hidden" name="action" value="save_profile">
            <div class="form-row three">
                <div class="form-group"><label>Country</label><input type="text" name="country" value="<?= e($profile['country'] ?? '') ?>"></div>
                <div class="form-group"><label>Academic Level</label><input type="text" name="academic_level" value="<?= e($profile['academic_level'] ?? '') ?>"></div>
                <div class="form-group"><label>GPA</label><input type="number" step="0.01" min="0" max="4.00" name="gpa" value="<?= e($profile['gpa'] ?? '') ?>"></div>
            </div>
            <div class="form-row three">
                <div class="form-group"><label>Field of Interest</label><input type="text" name="field_of_interest" value="<?= e($profile['field_of_interest'] ?? '') ?>"></div>
                <div class="form-group"><label>Preferred Country</label><input type="text" name="preferred_country" value="<?= e($profile['preferred_country'] ?? '') ?>"></div>
                <div class="form-group"><label>Preferred Language</label><input type="text" name="preferred_language" value="<?= e($profile['preferred_language'] ?? '') ?>"></div>
            </div>
            <div class="form-row three">
                <div class="form-group">
                    <label>English Test</label>
                    <select name="english_proof_status" id="englishSelect">
                        <option value="None" <?= $englishChoice==='None'?'selected':'' ?>>None yet</option>
                        <option value="IELTS" <?= $englishChoice==='IELTS'?'selected':'' ?>>IELTS</option>
                        <option value="TOEFL" <?= $englishChoice==='TOEFL'?'selected':'' ?>>TOEFL</option>
                        <option value="Duolingo" <?= $englishChoice==='Duolingo'?'selected':'' ?>>Duolingo</option>
                        <option value="PTE" <?= $englishChoice==='PTE'?'selected':'' ?>>PTE</option>
                        <option value="Cambridge" <?= $englishChoice==='Cambridge'?'selected':'' ?>>Cambridge</option>
                        <option value="Other" <?= $englishChoice==='Other'?'selected':'' ?>>Other</option>
                    </select>
                </div>
                <div class="form-group english-other <?= $englishChoice==='Other'?'':'hidden' ?>"><label>Other English Proof</label><input type="text" name="english_test_other" value="<?= e($profile['english_test_other'] ?? (str_starts_with((string)$englishCurrent,'Other:') ? trim(substr((string)$englishCurrent,6)) : '')) ?>" placeholder="Example: B1 German"></div>
                <div class="form-group"><label>Target Degree</label><input type="text" name="target_degree" value="<?= e($profile['target_degree'] ?? '') ?>"></div>
            </div>
            <div class="form-row three">
                <div class="form-group">
                    <label>Entry Exam</label>
                    <select name="entry_exam_status" id="examSelect">
                        <option value="None" <?= $entryChoice==='None'?'selected':'' ?>>None</option>
                        <option value="SAT" <?= $entryChoice==='SAT'?'selected':'' ?>>SAT</option>
                        <option value="ACT" <?= $entryChoice==='ACT'?'selected':'' ?>>ACT</option>
                        <option value="GRE" <?= $entryChoice==='GRE'?'selected':'' ?>>GRE</option>
                        <option value="GMAT" <?= $entryChoice==='GMAT'?'selected':'' ?>>GMAT</option>
                        <option value="Other" <?= $entryChoice==='Other'?'selected':'' ?>>Other</option>
                    </select>
                </div>
                <div class="form-group exam-other <?= $entryChoice==='Other'?'':'hidden' ?>"><label>Other Exam</label><input type="text" name="entry_exam_other" value="<?= e($profile['entry_exam_other'] ?? (str_starts_with((string)$entryCurrent,'Other:') ? trim(substr((string)$entryCurrent,6)) : '')) ?>"></div>
                <div class="form-group"><label>Target Intake</label><select name="target_intake"><option value="">Choose intake</option><option <?= ($profile['target_intake'] ?? '')==='Fall'?'selected':'' ?>>Fall</option><option <?= ($profile['target_intake'] ?? '')==='Spring'?'selected':'' ?>>Spring</option><option <?= ($profile['target_intake'] ?? '')==='Summer'?'selected':'' ?>>Summer</option><option <?= ($profile['target_intake'] ?? '')==='Winter'?'selected':'' ?>>Winter</option></select></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Budget Range</label><input type="text" name="budget_range" value="<?= e($profile['budget_range'] ?? '') ?>"></div>
                <div class="form-group"><label>Extracurricular Level</label><select name="extracurricular_level"><option <?= ($profile['extracurricular_level'] ?? '')==='None yet'?'selected':'' ?>>None yet</option><option <?= ($profile['extracurricular_level'] ?? 'Moderate')==='Moderate'?'selected':'' ?>>Moderate</option><option <?= ($profile['extracurricular_level'] ?? '')==='Strong'?'selected':'' ?>>Strong</option><option <?= ($profile['extracurricular_level'] ?? '')==='Excellent'?'selected':'' ?>>Excellent</option></select></div>
            </div>
            <div class="form-group"><label>Extracurricular Notes</label><textarea name="extracurriculars"><?= e($profile['extracurriculars'] ?? '') ?></textarea></div>
            <button class="btn" type="submit">Save profile</button>
        </form>
    </div>
    <div class="card pricing-box">
        <h3>How recommendation works</h3>
        <p class="muted">Recommendations use your GPA, target degree, preferred country, preferred language, and field of interest first.</p>
        <ul class="list-clean">
            <li>Language search is typed, not limited by a dropdown.</li>
            <li>Universities include official website details.</li>
            <li>Mentor money stays reserved by the platform first.</li>
            <li>Applications and reviews are saved in the database.</li>
        </ul>
    </div>
</div>

<div class="section-spacer"></div>
<div class="table-card">
    <div class="section-title"><h3>Recommended scholarships</h3><a class="btn secondary" href="search.php">Open full search</a></div>
    <?php if ($recommended): ?>
        <table class="table">
            <tr><th>Scholarship</th><th>University</th><th>Program</th><th>Country</th><th>Funding</th><th>Language</th><th>Action</th></tr>
            <?php foreach ($recommended as $row): ?>
                <tr>
                    <td><?= e($row['title']) ?><br><span class="muted">Deadline: <?= e($row['deadline']) ?></span></td>
                    <td><?= e($row['university_name']) ?></td>
                    <td><?= e($row['program_name']) ?></td>
                    <td><?= e($row['country']) ?></td>
                    <td><?= e($row['funding_type']) ?> / <?= e($row['scholarship_percentage']) ?>%</td>
                    <td><?= e($row['language_requirement']) ?></td>
                    <td><form method="post"><input type="hidden" name="action" value="apply"><input type="hidden" name="scholarship_id" value="<?= e($row['id']) ?>"><input type="hidden" name="program_id" value="<?= e($row['program_id']) ?>"><button class="btn small-btn">Apply</button></form></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?><div class="empty-state">The system has no recommendation for you at this moment.</div><?php endif; ?>
</div>

<div class="section-spacer"></div>
<div class="split-grid">
    <div class="form-card">
        <h3>Request a mentor session</h3>
        <form method="post">
            <input type="hidden" name="action" value="request_session">
            <div class="form-group"><label>Choose Mentor</label><select name="mentor_id" required><?php foreach ($mentors as $mentor): ?><option value="<?= e($mentor['id']) ?>"><?= e($mentor['name']) ?> - <?= e($mentor['expertise_area']) ?> ($<?= e(number_format((float)$mentor['min_session_fee'],2)) ?> to $<?= e(number_format((float)$mentor['max_session_fee'],2)) ?>)</option><?php endforeach; ?></select></div>
            <div class="form-row three">
                <div class="form-group"><label>Topic</label><input type="text" name="topic" required></div>
                <div class="form-group"><label>Preferred Date</label><input type="date" name="preferred_date"></div>
                <div class="form-group"><label>Session Duration</label><select name="session_duration_minutes"><option value="30">30 minutes</option><option value="45" selected>45 minutes</option><option value="60">60 minutes</option><option value="90">90 minutes</option></select></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Requested Fee (USD)</label><input type="number" step="0.01" name="requested_fee" value="18.00" required></div>
                <div class="form-group"><label>Payment Method</label><select name="payment_method"><option>Card via platform</option><option>Bank transfer via platform</option><option>Manual payment recorded by admin</option></select></div>
            </div>
            <div class="form-group"><label>Short Note for Mentor</label><textarea name="student_note" placeholder="What do you need help with?"></textarea></div>
            <p class="inline-note">To reduce cheating, the platform stores the payment as reserved first. The mentor payout is released later after the session is completed.</p>
            <button class="btn" type="submit">Send request</button>
        </form>
    </div>
    <div class="table-card">
        <h3>My mentorship requests</h3>
        <?php if ($sessions): ?><table class="table"><tr><th>Mentor</th><th>Topic</th><th>Duration / Fee</th><th>Status</th><th>Next Step</th></tr><?php foreach ($sessions as $s): ?><tr><td><?= e($s['mentor_name']) ?><br><span class="muted"><?= e($s['mentor_public_id']) ?></span></td><td><?= e($s['topic']) ?></td><td><?= e($s['session_duration_minutes']) ?> min<br>$<?= e(number_format((float)$s['session_fee'],2)) ?></td><td><span class="status <?= e(strtolower(str_replace(' ', '-', $s['request_status']))) ?>"><?= e($s['request_status']) ?></span><br><span class="muted">Payment: <?= e($s['payment_status']) ?></span></td><td><?php if (!empty($s['meeting_link'])): ?><a class="btn secondary small-btn" href="<?= e($s['meeting_link']) ?>" target="_blank">Join session</a><?php elseif ($s['request_status'] === 'Accepted' || $s['request_status'] === 'Scheduled'): ?><span class="muted">Mentor will add the meeting link soon.</span><?php elseif ($s['request_status'] === 'Completed'): ?><span class="muted">Session completed.</span><?php else: ?><span class="muted">Waiting for mentor response.</span><?php endif; ?></td></tr><?php endforeach; ?></table><?php else: ?><div class="empty-state">No mentor requests yet.</div><?php endif; ?>
    </div>
</div>

<div class="section-spacer"></div>
<div class="split-grid">
    <div class="table-card">
        <h3>My applications</h3>
        <?php if ($applications): ?><table class="table"><tr><th>Scholarship</th><th>Program</th><th>University</th><th>Status</th></tr><?php foreach ($applications as $a): ?><tr><td><?= e($a['title']) ?></td><td><?= e($a['program_name']) ?></td><td><?= e($a['university_name']) ?></td><td><span class="status <?= e(strtolower($a['status'])) ?>"><?= e($a['status']) ?></span></td></tr><?php endforeach; ?></table><?php else: ?><div class="empty-state">No scholarship applications yet. Apply from the search page or from the recommendations above.</div><?php endif; ?>
    </div>
    <div class="form-card">
        <h3>Add a review</h3>
        <form method="post">
            <input type="hidden" name="action" value="submit_review">
            <div class="form-row">
                <div class="form-group"><label>Entity Type</label><select name="entity_type" id="entityTypeSelect"><option value="university">University</option><option value="program">Program</option><option value="scholarship">Scholarship</option><option value="mentor">Mentor</option></select></div>
                <div class="form-group"><label>Rating</label><select name="rating"><?php for($i=5;$i>=1;$i--): ?><option value="<?= $i ?>"><?= $i ?>/5</option><?php endfor; ?></select></div>
            </div>
            <div class="form-group type-group group-university"><label>University</label><select name="entity_id_university"><?php foreach ($reviewEntities['universities'] as $entity): ?><option value="<?= e($entity['id']) ?>"><?= e($entity['name']) ?></option><?php endforeach; ?></select></div>
            <div class="form-group type-group group-program hidden"><label>Program</label><select name="entity_id_program"><?php foreach ($reviewEntities['programs'] as $entity): ?><option value="<?= e($entity['id']) ?>"><?= e($entity['name']) ?></option><?php endforeach; ?></select></div>
            <div class="form-group type-group group-scholarship hidden"><label>Scholarship</label><select name="entity_id_scholarship"><?php foreach ($reviewEntities['scholarships'] as $entity): ?><option value="<?= e($entity['id']) ?>"><?= e($entity['name']) ?></option><?php endforeach; ?></select></div>
            <div class="form-group type-group group-mentor hidden"><label>Mentor</label><select name="entity_id_mentor"><?php foreach ($reviewEntities['mentors'] as $entity): ?><option value="<?= e($entity['id']) ?>"><?= e($entity['name']) ?></option><?php endforeach; ?></select></div>
            <input type="hidden" name="entity_id" id="reviewEntityId" value="<?= e($reviewEntities['universities'][0]['id'] ?? '') ?>">
            <div class="form-group"><label>Comment</label><textarea name="comment"></textarea></div>
            <button class="btn" type="submit">Submit review</button>
        </form>
    </div>
</div>
<script>
const entityTypeSelect = document.getElementById('entityTypeSelect');
const hiddenEntity = document.getElementById('reviewEntityId');
function syncReviewEntity(){
  document.querySelectorAll('.type-group').forEach(el=>el.classList.add('hidden'));
  const type = entityTypeSelect.value;
  const group = document.querySelector('.group-'+type);
  if(group){group.classList.remove('hidden');
    hiddenEntity.value = group.querySelector('select').value;
    group.querySelector('select').onchange = e => hiddenEntity.value = e.target.value;
  }
}
entityTypeSelect.addEventListener('change', syncReviewEntity); syncReviewEntity();
const englishSelect = document.getElementById('englishSelect');
const examSelect = document.getElementById('examSelect');
function toggleExtra(selectId, selector){
  const select = document.getElementById(selectId);
  const box = document.querySelector(selector);
  if(!select || !box) return;
  const sync = () => box.classList.toggle('hidden', select.value !== 'Other');
  select.addEventListener('change', sync); sync();
}
toggleExtra('englishSelect', '.english-other');
toggleExtra('examSelect', '.exam-other');
</script>
<?php include __DIR__ . '/partials/footer.php'; ?>
